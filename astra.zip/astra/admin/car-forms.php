<?php
global $wpdb;
$table_name = $wpdb->prefix.'auto_forms_data';
$items_per_page = 10;
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;

$query = 'SELECT * FROM '.$table_name;
$total_query = "SELECT COUNT(1) FROM (${query}) AS combined_table";
$total = $wpdb->get_var( $total_query );

$forms = $wpdb->get_results( $query.' ORDER BY id DESC LIMIT '. $offset.', '. $items_per_page, ARRAY_A);
?>
<div class="container forms-custom">
	<a class="go_to_next" href="?page=custom-forms-data">Back</a>
	<a class="go_to_next" href="?page=home-forms">Home Forms</a>
	<div class="container-main" id="rich-picks-admin">
	    <div id="" class="wrap">
	        <h1 style="text-align: center;font-weight: 600;">Submitted Auto Forms</h1>
	        <div>
	        	<div class="pagination_qulifire">
			    	<?php 
				    	echo paginate_links( array(
				            'base' => add_query_arg( 'cpage', '%#%' ),
				            'format' => '',
				            'prev_text' => __('&laquo;'),
				            'next_text' => __('&raquo;'),
				            'total' => ceil($total / $items_per_page),
				            'current' => $page
				        ));
				    ?>
			    </div>
			    <!-- <form class="search-form">
					<input type="search" name="form-search-custom" class="form-search-custom" placeholder="Search Name" id="search-user" onkeyup="searchUser()">
				</form> -->
	        </div>
	        <table class="form-table" id="qualified-table">
	            <thead>
	                <tr>
	                    <th>Name</th>
	                    <th>Email</th>
	                    <th>Phone</th>
	                    <th>Adress</th>
	                    <th>View Data</th>
	                </tr>
	            </thead>
	            <tbody class="row">
	                <?php 
	                    foreach($forms as $form){
	                    	
	                ?>
	                <tr id="<?php echo $form['id']; ?>">
	                	<td>
	                		<?php echo $form['fname']; ?>
	                	</td>
	                	<td>
	                		<?php echo $form['email']; ?>
	                	</td>
	                	<td>
	                		<?php echo $form['phone']; ?>
	                	</td>
	                	<td>
	                		<?php echo $form['adress']; ?>
	                	</td>
	                	<td>
	                		<form action="<?php echo '?page=view-form-details&form=auto&id='.$form['id']; ?>" method="post" id="prs_form" name="prs_form">
	                			<input class="go_to_next" value="View" type="submit" name="sumbit">
	                		</form>
	                	</td>
	                </tr>
	                <?php } ?>
	            </tbody>
	        </table>
	    </div>
	</div>
</div>

<style type="text/css">
.forms-custom{
	max-width: 1140px;
    margin: 60px auto 0;
}
.forms-custom h4{
	font-size: 25px;
    line-height: 25px;
    margin-bottom: 15px;
}
.go_to_next{
    text-decoration: none;
    border: 1px solid #2271b1;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
    margin-right: 20px;
    color: #2271b1;
    cursor: pointer;
}
.forms-custom table.form-table, tr, td {
	border: 1px solid black;
	padding: 5px;
	border-collapse: collapse;
	text-align: center;
}
.forms-custom table.form-table thead{
    background: #1d2327;
}
.forms-custom table.form-table thead tr th{
    text-align: center;
    color: #fff;
}
.forms-custom .del-qulifier{
	color: #fff;
    background: #e01616;
    border: none;
    padding: 5px 20px;
    box-sizing: border-box;
    font-weight: 900;
    line-height: 20px;
}
.forms-custom .pagination_qulifire{
	padding: 0px 20px;
	width: 49%;
	display: inline-block;
}
.forms-custom .pagination_qulifire .page-numbers{
	font-size: 27px;
    line-height: 36px;
    text-decoration: none;
    background: #1e1e1e;
    padding: 0px 5px;
    color: #fff;
    display: inline-block;
    margin-top: 20px;
}
.forms-custom .pagination_qulifire .page-numbers.current{
	font-size: 27px;
    line-height: 36px;
    text-decoration: none;
    background: #3858e9;
    padding: 0px 5px;
    color: #fff;
    display: inline-block;
    margin-top: 20px;
}
.forms-custom .search-form{
	text-align: right;
	width: 100%;
	display: inline-block;
}
.forms-custom .form-search-custom{
	margin: 20px 0px;
    padding: 10px 20px!important;
}
</style>
<!-- <script type="text/javascript">
	function searchUser() {
	  	var input, filter, table, tr, td, i, txtValue;
	  	input = document.getElementById("search-user");
	  	filter = input.value.toUpperCase();
	  	table = document.getElementById("qualified-table");
	  	tr = table.getElementsByTagName("tr");
	  	for (i = 0; i < tr.length; i++) {
	    	td = tr[i].getElementsByTagName("td")[0];
	    	if (td) {
	      		txtValue = td.textContent || td.innerText;
	      		if (txtValue.toUpperCase().indexOf(filter) > -1) {
	        		tr[i].style.display = "";
	      		} else {
	        		tr[i].style.display = "none";
	      		}
	    	}       
	  	}
	}
</script> -->