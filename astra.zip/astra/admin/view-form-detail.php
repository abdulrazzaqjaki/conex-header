<!-- home form get data and display Start -->
<?php
global $wpdb;
if(isset($_GET['form']) && isset($_GET['id'])) {

	if ($_GET['form'] == 'home') {

		$table_user = $wpdb->prefix.'home_forms_data';

		$back_link = '?page=home-forms';

		$id = $_GET['id'];

		$user_data = $wpdb->get_results( "SELECT * FROM $table_user WHERE id=$id", ARRAY_A);

		$fname = $user_data[0]['fname'];
		$lname = $user_data[0]['lname'];
		$email = $user_data[0]['email'];
		$phone = $user_data[0]['phone'];
		$adress = $user_data[0]['adress'];
		$DOB = $user_data[0]['DOB'];
		$city = $user_data[0]['city'];
		$state = $user_data[0]['state'];
		$zip = $user_data[0]['zip'];
		$home = $user_data[0]['home'];
		$property_address = $user_data[0]['property_address'];
		$unit = $user_data[0]['unit'];
		$vinnumbr = $user_data[0]['vinnumbr'];
		$occupancy = $user_data[0]['occupancy'];
		$primary_home = $user_data[0]['primary_home'];
		$use_property = $user_data[0]['use_property'];
		$year_built = $user_data[0]['year_built'];
		$square_feet = $user_data[0]['square_feet'];
		$construction_type = $user_data[0]['construction_type'];
		$roof_type = $user_data[0]['roof_type'];
		$roof_shape = $user_data[0]['roof_shape'];
		$number_of_rooms = $user_data[0]['number_of_rooms'];
		$number_of_stories = $user_data[0]['number_of_stories'];
		$contents = $user_data[0]['contents'];
		$liability_limits = $user_data[0]['liability_limits'];
		$medical_payments = $user_data[0]['medical_payments'];
		$residence_passed = $user_data[0]['residence_passed'];
		$insurance_claims = $user_data[0]['insurance_claims'];
		$type_of_loss = $user_data[0]['type_of_loss'];
		$paid_by_carrier = $user_data[0]['paid_by_carrier'];
		$date_of_occurance = $user_data[0]['date_of_occurance'];
		$have_any_pets = $user_data[0]['have_any_pets'];
		$gated_community = $user_data[0]['gated_community'];
		$burglar_alarm = $user_data[0]['burglar_alarm'];
		$roof_replaced = $user_data[0]['roof_replaced'];
		$roof_replaced_year = $user_data[0]['roof_replaced_year'];
		$built_over_sand = $user_data[0]['built_over_sand'];
		$built_over_water = $user_data[0]['built_over_water'];
		$roof_year = $user_data[0]['roof_year'];
		$electrical_year = $user_data[0]['electrical_year'];
		$plumbing_year = $user_data[0]['plumbing_year'];
		$heating_year = $user_data[0]['heating_year'];
		$sinkhole_activity = $user_data[0]['sinkhole_activity'];
		$swimming_pool = $user_data[0]['swimming_pool'];
		$swimming_pool_ground = $user_data[0]['swimming_pool_ground'];
		$swimming_pool_foundation = $user_data[0]['swimming_pool_foundation'];
		$house_frame = $user_data[0]['house_frame'];
		$primary_heating = $user_data[0]['primary_heating'];
		$hydrant_feet = $user_data[0]['hydrant_feet'];
		$fire_station = $user_data[0]['fire_station'];
		$flood_zone = $user_data[0]['flood_zone'];
		$cu_insured = $user_data[0]['cu_insured'];
		$namedInsured = $user_data[0]['namedInsured'];
		$gender = $user_data[0]['gender'];
		$maritalStatus = $user_data[0]['maritalStatus'];
		$educationLevel = $user_data[0]['educationLevel'];
		$occupation = $user_data[0]['occupation'];
		$ownRent = $user_data[0]['ownRent'];
?>
<div class="container forms-custom">
	<div class="container-main" id="rich-picks-admin">
		<a class="go_to_next" href="<?php echo $back_link; ?>">Go Back</a>
		<form>
			<div class="row head-user-data">
				<div class="col-md-6">
					<p class="">Questions</p>
				</div>
				<div class="col-md-6">
					<p class="">Answers</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">User ID</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $id; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">First Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $fname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Last Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $lname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Email</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $email; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Phone Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $phone; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Adress</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $adress; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Date of Birth</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $DOB; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">City</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $city; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">State</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $state; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Zip Code</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $zip; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Select the Style of Your Home</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $home; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Property Address</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $property_address; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">unit</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $unit; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">VIN Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $vinnumbr; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Occupancy</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $occupancy; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Is this your primary home?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $primary_home; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Year Built</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $year_built; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Square Feet</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $square_feet; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Construction Type</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $construction_type; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Roof Type</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $roof_type; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Roof shape</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $roof_shape; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">How many rooms?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $number_of_rooms; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Number of stories</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $number_of_stories; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Contents</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $contents; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Liability limits</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $liability_limits; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Medical payments</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $medical_payments; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Any residence of the house has passed or has of the following</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $residence_passed; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Insurance claims?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $insurance_claims; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Description type of loss</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $type_of_loss; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Amount Paid by Carrier</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $paid_by_carrier; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Date Of Occurance</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $date_of_occurance; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Do you have any pets?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $have_any_pets; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Gated Community</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $gated_community; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Burglar Alarm</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $burglar_alarm; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Has your roof been replaced?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $roof_replaced; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">What Year?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $roof_replaced_year; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Built over sand?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $built_over_sand; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Built over water?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $built_over_water; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">In what year were these systems repaired</p>
					<p class="question">Roof Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $roof_year; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Electrical Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $electrical_year; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Plumbing Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $plumbing_year; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Heating Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $heating_year; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Sinkhole activity?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $sinkhole_activity; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Swimming Pool?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $swimming_pool; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Swimming Pool Ground?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $swimming_pool_ground; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">What type of foundation?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $swimming_pool_foundation; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Frame of the house?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $house_frame; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Home’s primary heating?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $primary_heating; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Hydrant within 1,000 feet?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $hydrant_feet; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Nearest fire station?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $fire_station; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Flood Zone</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $flood_zone; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Currently Insured?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $cu_insured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Named of current insurer</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $namedInsured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Gender</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $gender; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Marital Status</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $maritalStatus; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Education Level</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $educationLevel; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Occupation</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $occupation; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Own Or Rent House</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ownRent; ?></p>
				</div>
			</div>
		</form>
	</div>
</div>
<!-- home form get data and display End -->
<!-- auto form get data and display Start -->
<?php

	}elseif ($_GET['form'] == 'auto') {

		$table_user = $wpdb->prefix.'auto_forms_data';

		$back_link = '?page=auto-forms';

		$id = $_GET['id'];

		$user_data = $wpdb->get_results( "SELECT * FROM $table_user WHERE id=$id", ARRAY_A);
		$id =  $user_data[0]['id'];
		$fname = $user_data[0]['fname'];
		$lname = $user_data[0]['lname'];
		$email = $user_data[0]['email'];
		$phone = $user_data[0]['phone'];
		$adress = $user_data[0]['adress'];
		$DOB = $user_data[0]['DOB'];
		$city = $user_data[0]['city'];
		$state = $user_data[0]['state'];
		$zip = $user_data[0]['zip'];
		$autoYear = $user_data[0]['autoYear'];
		$autoMake = $user_data[0]['autoMake'];
		$autoModal = $user_data[0]['autoModal'];
		$vinnumbr = $user_data[0]['vinnumbr'];
		$primaryVehicleUse = $user_data[0]['primaryVehicleUse'];
		$commuteDistance = $user_data[0]['commuteDistance'];
		$work_sch = $user_data[0]['work_sch'];
		$ownLease = $user_data[0]['ownLease'];
		$makePay = $user_data[0]['makePay'];
		$have_veh = $user_data[0]['have_vehicle'];
		$ride_shr = $user_data[0]['ride_share'];
		$cu_insured = $user_data[0]['cu_insured'];
		$namedInsured = $user_data[0]['namedInsured'];
		$liability = $user_data[0]['liability'];
		$coverage = $user_data[0]['coverage'];
		$gender = $user_data[0]['gender'];
		$maritalStatus = $user_data[0]['maritalStatus'];
		$educationLevel = $user_data[0]['educationLevel'];
		$occupation = $user_data[0]['occupation'];
		$ownRent = $user_data[0]['ownRent'];
		$LicenseStatus = $user_data[0]['licenseStatus'];
		$SR_22_doc = $user_data[0]['sr_22_doc'];
		$faultAccidents = $user_data[0]['faultAccidents'];
		$PIPAccident = $user_data[0]['PIPAccident'];
?>
<div class="container forms-custom">
	<div class="container-main" id="rich-picks-admin">
		<a class="go_to_next" href="<?php echo $back_link; ?>">Go Back</a>
		<form>
			<div class="row head-user-data">
				<div class="col-md-6">
					<p class="">Questions</p>
				</div>
				<div class="col-md-6">
					<p class="">Answers</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">User ID</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $id; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">First Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $fname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Last Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $lname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Email</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $email; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Phone Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $phone; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Adress</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $adress; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Date of Birth</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $DOB; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">City</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $city; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">State</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $state; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Zip Code</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $zip; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoYear; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Make</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoMake; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Modal</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoModal; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">VIN Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $vinnumbr; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">What is this car's primary use?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $primaryVehicleUse; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">About how many miles each way?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $commuteDistance; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Drive To Work Or School</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $work_sch; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Owned Or Lease</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ownLease; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Do You Currently Make Payments On This Car?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $makePay; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">How Long Have You Had This Vehicle?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $have_veh; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Used for RideSharnig</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ride_shr; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Currently Insured?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $cu_insured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Named of current insurer</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $namedInsured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Your Current liability Limits</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $liability; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Your Current Comprehensive / Collision</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $coverage; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Gender</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $gender; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Marital Status</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $maritalStatus; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Education Level</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $educationLevel; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Occupation</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $occupation; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Own Or Rent House</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ownRent; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">License Status</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $LicenseStatus; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Are you required to have an SR-22 or other Financial Responsibility document?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $SR_22_doc; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Any at –fault accidents in the last 3 years?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $faultAccidents; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Have You had a PIP Accident in the last 5 Years?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $PIPAccident; ?></p>
				</div>
			</div>
		</form>
	</div>
</div>
<?php 
}else{

	echo 'nothing found';

}


?>
<style type="text/css">
.forms-custom{
	max-width: 1140px;
    margin: 60px auto 0;
}
.forms-custom h4{
	font-size: 25px;
    line-height: 25px;
    margin-bottom: 15px;
}
.forms-custom .row{
	display: flex;
	flex-wrap: wrap;
}
.forms-custom .ans{
    font-weight: 600;
}
.forms-custom .question{
    font-weight: 600;
    font-size: 14px;
}
.forms-custom .col-md-6{
	width: 49%;
	padding: 0px 15px;
	box-sizing: border-box;
	border: 1px solid #ccc;
}
.forms-custom .head-user-data .col-md-6{
    background: #1d2327;
        margin-top: 30px;
}
.forms-custom .head-user-data p{
    font-size: 20px;
    line-height: 0;
    text-align: center;
    font-weight: 600;
    color: #fff;
}
.go_to_next{
    text-decoration: none;
    border: 1px solid #2271b1;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
    margin-right: 20px;
    color: #2271b1;
    cursor: pointer;
    display: inline-block;
}
.forms-custom table.form-table, tr, td {
	border: 1px solid black;
	padding: 5px;
	border-collapse: collapse;
	text-align: center;
}
.forms-custom table.form-table thead{
    background: #fff;
}
.forms-custom table.form-table thead tr th{
    text-align: center;
}
</style>

<?php 
}else{
	echo "nothing found";
} 
?>