

<div class="container forms-custom">
	<h1>Select which forms data you want to check</h1>
	<div class="row">
		<div class="col-md-6">
			<h4>Home Forms</h4>
			<a href="?page=home-forms" class="forms-btn"><span class="dashicons dashicons-admin-home"></span></a>
		</div>
		<div class="col-md-6">
			<h4>Auto Forms</h4>
			<a href="?page=auto-forms" class="forms-btn"><span class="dashicons dashicons-car"></span></a>
		</div>
	</div>
</div>

<style type="text/css">
	.forms-custom{
		max-width: 869px;
	    margin: 60px auto 0;
	    text-align: center;
	}
	.forms-custom .row{
		display: flex;
		flex-wrap: wrap;
	}
	.forms-custom .col-md-6{
		width: 49%;
		padding: 0px 15px;
		box-sizing: border-box;
	}
	.forms-custom a{
		display: block;
	    text-decoration: none;
	    /*font-size: 40px;*/
        max-width: 46%;
	    margin: 0 auto;
	    line-height: 104px;
	    text-align: center;
	    background: #2271b1;
	    color: #fff;
	    border-radius: 13px;
	}
	.forms-custom .dashicons{
	    font-size: 95px;
    	display: inline-table;
	}
	.forms-custom h4{
		font-size: 25px;
	    line-height: 25px;
	    margin-bottom: 15px;
	}
</style>