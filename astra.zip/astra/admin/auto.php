<?php
	global $wpdb;

	$table_user = $wpdb->prefix.'auto_forms_data';

	$back_link = '?page=auto-forms';

	$id = $_GET['id'];

	$user_data = $wpdb->get_results( "SELECT * FROM $table_user WHERE id=$id", ARRAY_A);
	$id =  $user_data[0]['id'];
	$fname = $user_data[0]['fname'];
	$lname = $user_data[0]['lname'];
	$email = $user_data[0]['email'];
	$phone = $user_data[0]['phone'];
	$adress = $user_data[0]['adress'];
	$DOB = $user_data[0]['DOB'];
	$city = $user_data[0]['city'];
	$state = $user_data[0]['state'];
	$zip = $user_data[0]['zip'];
	$autoYear = $user_data[0]['autoYear'];
	$autoMake = $user_data[0]['autoMake'];
	$autoModal = $user_data[0]['autoModal'];
	$vinnumbr = $user_data[0]['vinnumbr'];
	$primaryVehicleUse = $user_data[0]['primaryVehicleUse'];
	$commuteDistance = $user_data[0]['commuteDistance'];
	$work_sch = $user_data[0]['work_sch'];
	$ownLease = $user_data[0]['ownLease'];
	$makePay = $user_data[0]['makePay'];
	$have_veh = $user_data[0]['have_vehicle'];
	$ride_shr = $user_data[0]['ride_share'];
	$cu_insured = $user_data[0]['cu_insured'];
	$namedInsured = $user_data[0]['namedInsured'];
	$liability = $user_data[0]['liability'];
	$coverage = $user_data[0]['coverage'];
	$gender = $user_data[0]['gender'];
	$maritalStatus = $user_data[0]['maritalStatus'];
	$educationLevel = $user_data[0]['educationLevel'];
	$occupation = $user_data[0]['occupation'];
	$ownRent = $user_data[0]['ownRent'];
	$LicenseStatus = $user_data[0]['licenseStatus'];
	$SR_22_doc = $user_data[0]['sr_22_doc'];
	$faultAccidents = $user_data[0]['faultAccidents'];
	$PIPAccident = $user_data[0]['PIPAccident'];
?>
<div class="container forms-custom">
	<div class="container-main" id="rich-picks-admin">
		<a class="go_to_next" href="<?php echo $back_link; ?>">Go Back</a>
		<form>
			<div class="row head-user-data">
				<div class="col-md-6">
					<p class="">Questions</p>
				</div>
				<div class="col-md-6">
					<p class="">Answers</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">User ID</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $id; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">First Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $fname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Last Name</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $lname; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Email</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $email; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Phone Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $phone; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Adress</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $adress; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Date of Birth</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $DOB; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">City</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $city; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">State</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $state; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Zip Code</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $zip; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Year</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoYear; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Make</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoMake; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Auto Modal</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $autoModal; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">VIN Number</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $vinnumbr; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">What is this car's primary use?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $primaryVehicleUse; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">About how many miles each way?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $commuteDistance; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Drive To Work Or School</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $work_sch; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Owned Or Lease</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ownLease; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Do You Currently Make Payments On This Car?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $makePay; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">How Long Have You Had This Vehicle?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $have_veh; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Used for RideSharnig</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ride_shr; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Currently Insured?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $cu_insured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Named of current insurer</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $namedInsured; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Your Current liability Limits</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $liability; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Your Current Comprehensive / Collision</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $coverage; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Gender</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $gender; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Marital Status</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $maritalStatus; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Education Level</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $educationLevel; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Occupation</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $occupation; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Own Or Rent House</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $ownRent; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">License Status</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $LicenseStatus; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Are you required to have an SR-22 or other Financial Responsibility document?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $SR_22_doc; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Any at –fault accidents in the last 3 years?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $faultAccidents; ?></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<p class="question">Have You had a PIP Accident in the last 5 Years?</p>
				</div>
				<div class="col-md-6">
					<p class="ans"><?php echo $PIPAccident; ?></p>
				</div>
			</div>
		</form>
	</div>
</div>

<?php } ?>