<?php /* Template Name: Cars Form */ ?>

<?php get_header(); ?>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style type="text/css">

.page-title{
    margin-top: 150px;
    text-align: center;
}
* {
    margin: 0;
    padding: 0
}

html {
    height: 100%
}
h1,h2,h3,h4,h5,h6{
    color: #054f93;
}
#heading {
    text-transform: uppercase;
    color: #054f93;
    font-weight: normal
}



#msform fieldset:not(:first-of-type) {
    display: none;
}

#msform input,
#msform textarea {
    padding: 8px 15px 8px 15px;
    border: 1px solid #054f93;
    border-radius: 6px;
    margin-bottom: 25px;
    margin-top: 2px;
    width: 100%;
    box-sizing: border-box;
    color: #2C3E50;
    background-color: transparent;
    font-size: 16px;
    letter-spacing: 1px
}

#msform input:focus,
#msform textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #054f93;
    outline-width: 0
}

#msform .action-button {
    width: 100px;
    background: #054f93;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 0px 10px 5px;
    float: right
}
#msform .action-button-previous {
    width: 100px;
    background: #054f93;
    color: #fff;
    border: 0 none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right;
}
.card {
    border: none;
}
.steps {
    font-size: 21px;
    color: #054f93;
    text-align: right
}
.fieldlabels {
    color: #054f93;
    text-align: left;
    display: block;
}
.progress {
    height: 8px
}
.select2-container{
    width: 100%!important;
    text-align: left;
}
.select2-container--default .select2-selection--single .select2-selection__arrow b{
    margin-top: 8px;
    
    border-color: #054f93 transparent transparent transparent;
}
.select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b{
    border-color: transparent transparent #054f93 transparent;
}

.select2-container--default .select2-selection--single{
    height: 41.12px;
    padding-top: 5px;
    border: 1px solid #054f93;
    margin-bottom: 25px;
    margin-top: 2px;
}
.select2-container--default .select2-search--dropdown .select2-search__field,
.select2-dropdown{
    border: 1px solid #054f93;
}
.select2-container--default .select2-results__option--highlighted[aria-selected]{
    background-color: #054f93;
}
.progress-bar {
    background-color: #054f93;
}

.fit-image {
    width: 100%;
    object-fit: cover
}
.form-card{
    text-align: left;
}
.primaryUse div input{
    -webkit-touch-callout: none;
    -webkit-tap-highlight-color: transparent;
    position: absolute;
    left: 0;
    top: 0;
    margin: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
    outline: 0;
}
.primaryUse div label{
    box-shadow: 0 2px 1px 0 rgb(0 0 0 / 6%);
    border-radius: 2.25em;
    transition: all .3s ease;
    margin: 0;
    border: 1px solid #054f93;
    display: block;
    text-align: center;
    background: #fff;
    color: #054f93;
    font-size: .8125em;
    border-radius: 1.0625rem;
    padding: .5em;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}
.primaryUse div{
    display: inline-block;
    vertical-align: top;
    width: auto;
    min-width: 6.5em;
    margin: 0 .75em .75em 0;
    padding: 0;
    position: relative;
}
.primaryUse div:hover label {
    color: #054f93;
    border: 1px solid #054f93;
    box-shadow: none;
}
.primaryUse{
    text-align: left;
}
.primaryUse div label i {
    font-weight: 300;
    line-height: 1;
    pointer-events: none;
    display: block;
    margin-bottom: .2rem;
    font-size: 3.5em;
    width: 100%;
}
.primaryUse div.selected label {
    background: #054f93;
    color: #fff;
    border: 1px solid #054f93;
}
.commuteDistance div{
    min-width: 6.5em;
}
.have_veh div{
    min-width: 11.5em;
}
.primaryUse .fieldlabels{
    margin-bottom: 30px;
}
.commuteDistance .fieldlabels{
    margin:30px 0px;
}
.make_pay,#insured_named{
    display: none;
}
#circleBar {
  text-align: center;
}
#circleBar .round {
  position: relative;
}
#circleBar canvas{
    transform: rotate(90deg);
}
#circleBar .round strong {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50% , -65%);
    font-size: 20px;
    color: #212121;
    font-weight: 400;
}
#circleBar span {
  display: block;
  color: #999;
  font-size: 16px;
  /*margin-top: 10px;*/
}
#circleBar span i {
  color: #ff5c5c;
  font-size: 22px;
  margin-right: 6px;
}
.err{
    display: none;
    margin: 0.5em 0 0;
    font-size: .85em;
    color: #bd003b;
}
#msform input[type='submit']{
    width: 100px;
    background: #054f93;
    color: #fff;
    border: 0 none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right;
}
#msform .row{
    text-align: left;
}
.thankyou-call-us{
    background: #054f93;
    padding: 50px 0;
    display: none;
}
.thankyou-call-us-heading-title{
    color: #fff;
    text-align: center;
    margin-top: 50px;
}
.thankyou-call-us-divider-separator{
    display: block;
    width: 50px;
    height: 3px;
    background: rgba(255,255,255,.5);
    margin:20px auto;
}
.thankyou-call-us-text{
    color: #fff;
    font-size: 18px;
    text-align: center;
    font-family: "Work Sans", sans-serif;
    padding: 10px 0;
}
.thankyou-call-us-cta{
    text-decoration: none !important;
    padding: 13px 35px;
    background: #fff;
    color: #000;
    display: block;
    margin: 20px auto 50px;
    width: max-content;
    font-size: 16px;
    font-family: "Work Sans", sans-serif;
    text-transform: capitalize;
    border: 1px solid #fff;
}
.thankyou-call-us-cta:hover{
    background: transparent;
    color: #fff;
}
</style>
<div class="container-fluid">
	<div class="container">
		<div class="page-title">
			<!-- <h1><?php //the_title(); ?></h1> -->
		</div>
	</div>
</div>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 text-center p-0 mt-3 mb-2">
            <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                <form id="msform" method="post" action="">
                    <div id="circleBar">
                        <div class="round" data-value="0.0" data-size="80" data-thickness="6"><strong>Start</strong></div>
                    </div>
                     <br>
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 1 - 8</h2>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-6">
                              <label class="fieldlabels">Year</label> 
                                <select name="autoYear" id="years" class="single" class="js-states form-control">
                                </select>
                                <span class="err" id="err-years">Required</span>   
                            </div>
                            <div class="col-6">
                              <label class="fieldlabels">Make</label> 
                                <select name="autoMake" id="makes" class="single" class="js-states form-control">
                                </select>
                                <span class="err" id="err-makes">Required</span>   
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                              <label class="fieldlabels">Modal</label> 
                                <select name="autoModal" id="models" class="single" class="js-states form-control">
                                </select>
                                <span class="err" id="err-models">Required</span>   
                            </div>
                            <div class="col-6">
                              <label class="fieldlabels">VIN Number</label> 
                                <input id="vinnumber" type="text" name="vinnumbr" placeholder="Enter VIN Number" />
                                <span class="err" id="err-vinnumber">Required</span>
                            </div>
                        </div>
                        <input id="scnd_step" type="button" name="next" class="next action-button" value="Next" /> 
                    </fieldset>
                    <!-- END 1st Step -->
                    <!-- Start 2nd Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 2 - 8</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse">
                            <label class="fieldlabels" id="primaryVehicleUse">What is this car's primary use?</label>
                            <div class="commuting">
                                <input type="radio" name="primaryVehicleUse" id="primaryVehicleUse_0" value="Commuting">
                                <label for="primaryVehicleUse_0"><i class="fas fa-route"></i></i>Commuting</label>
                            </div>
                            <div class="personal">
                                <input type="radio" name="primaryVehicleUse" id="primaryVehicleUse_1" value="Personal">
                                <label for="primaryVehicleUse_1"><i class="fas fa-car-side"></i>Personal</label>
                            </div>
                            <div class="business">
                                <input type="radio" name="primaryVehicleUse" id="primaryVehicleUse_2" value="Business">
                                <label for="primaryVehicleUse_2" ><i class="fas fa-car"></i>Business</label>
                            </div>
                            <div class="farming">
                                <input type="radio" name="primaryVehicleUse" id="primaryVehicleUse_3" value="Farming">
                                <label for="primaryVehicleUse_3"><i class="fas fa-truck-pickup"></i>Farming</label>
                            </div>
                            <div class="other">
                                <input type="radio" name="primaryVehicleUse" id="primaryVehicleUse_4" value="Other">
                                <label for="primaryVehicleUse_4"><i class="fas fa-map-signs"></i>Other</label>
                            </div>
                            <p>
                                <span class="err" id="err-primaryVehicleUse">Required</span>
                            </p>
                        </div> 
                        <div class="primaryUse commuteDistance">
                            <label class="fieldlabels" id="commuteDistance">About how many miles each way?</label>
                            <div class="selected">
                                <input type="radio" id="commuteDistance_0" name="commuteDistance" value="<5">
                                <label for="commuteDistance_0" >&lt; 5</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_1" name="commuteDistance" value="5">
                                <label for="commuteDistance_1">5</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_2" name="commuteDistance" value="10">
                                <label for="commuteDistance_2">10</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_3" name="commuteDistance" value="15">
                                <label for="commuteDistance_3">15</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_4" name="commuteDistance" value="20">
                                <label for="commuteDistance_4">20</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_5" name="commuteDistance" value="25">
                                <label for="commuteDistance_5">25</label>
                            </div>
                            <div>
                                <input type="radio" id="commuteDistance_6" name="commuteDistance" value="30+">
                                <label for="commuteDistance_6">30+</label>
                            </div>
                            <p>
                                <span class="err" id="err-commuteDistance">Required</span>  
                            </p>
                        </div>
                        <div class="primaryUse commuteDistance work_sch">
                            <label class="fieldlabels" id="work_sch">Drive To Work Or School</label>
                            <div>
                                <input class="wrkSh" type="radio" id="work_sch_0" name="work_sch" value="Work">
                                <label for="work_sch_0">Work</label>
                            </div>
                            <div>
                                <input class="wrkSh" type="radio" id="work_sch_1" name="work_sch" value="School">
                                <label for="work_sch_1">School</label>
                            </div>
                            <p>
                               <span class="err" id="err-work_sch">Required</span> 
                            </p>
                        </div>
                        <input id="third_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 2nd Step -->
                    <!-- Start 3rd Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 3 - 8</h2>
                                </div>
                            </div>
                            <div class="primaryUse commuteDistance own_lease">
                                <label class="fieldlabels" id="own_lease">Owned Or Lease</label>
                                <div>
                                    <input type="radio" id="Own" name="ownLease" value="Own">
                                    <label for="Own">Own</label>
                                </div>
                                <div>
                                    <input type="radio" id="Lease" name="ownLease" value="Lease">
                                    <label for="Lease">Lease</label>
                                </div>
                                <p>
                                   <span class="err" id="err-ownLease">Required</span> 
                                </p>
                            </div>

                            <div class="primaryUse commuteDistance make_pay">
                                <label class="fieldlabels" id="make_pay">Do You Currently Make Payments On This Car?</label>
                                <div>
                                    <input type="radio" id="makePay_0" name="makePay" value="Yes">
                                    <label for="makePay_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="makePay_1" name="makePay" value="No">
                                    <label for="makePay_1">NO</label>
                                </div>
                                <p>
                                   <span class="err" id="err-makePay">Required</span> 
                                </p>
                            </div>
                            <div class="primaryUse commuteDistance have_veh">
                                <label class="fieldlabels" id="have_veh">How Long Have You Had This Vehicle?</label>
                                <div>
                                    <input type="radio" id="have_veh_0" name="have_veh" value="1">
                                    <label for="have_veh_0">Less then 6 months</label>
                                </div>
                                <div>
                                    <input type="radio" id="have_veh_1" name="have_veh" value="2">
                                    <label for="have_veh_1">6 months to 1 year</label>
                                </div>
                                <div>
                                    <input type="radio" id="have_veh_2" name="have_veh" value="3">
                                    <label for="have_veh_2">1 to 2 years</label>
                                </div>
                                <div>
                                    <input type="radio" id="have_veh_3" name="have_veh" value="4">
                                    <label for="have_veh_3">2 to 5 years</label>
                                </div>
                                <div>
                                    <input type="radio" id="have_veh_4" name="have_veh" value="5">
                                    <label for="have_veh_4">5 or more year</label>
                                </div>
                                <p>
                                   <span class="err" id="err-have_veh">Required</span> 
                                </p>
                            </div>
                            <div class="primaryUse commuteDistance ride_shr">
                                <label class="fieldlabels" id="ride_shr">Used for RideSharnig</label>
                                <div>
                                    <input type="radio" id="ride_shr_0" name="ride_shr" value="Yes">
                                    <label for="ride_shr_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="ride_shr_1" name="ride_shr" value="No">
                                    <label for="ride_shr_1">NO</label>
                                </div>
                                <p>
                                   <span class="err" id="err-ride_shr">Required</span> 
                                </p>
                            </div>
                        </div> 
                        <input id="forth-step" type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 3rd Step -->
                    <!-- Start 4th Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 4 - 8</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse commuteDistance cu_insured">
                            <label class="fieldlabels" id="cu_insured">Currently Insured?</label>
                            <div>
                                <input type="radio" id="Yes" name="cu_insured" value="Yes">
                                <label for="cu_insured_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="No" name="cu_insured" value="No">
                                <label for="ride_shr_1">NO</label>
                            </div>
                            <p>
                               <span class="err" id="err-cu_insured">Required</span> 
                            </p>
                        </div>
                        <div id="insured_named">
                            <div class="row" >
                                <div class="col-6">
                                  <label class="fieldlabels">Named of current insurer</label> 
                                    <select id="namedInsured" name="namedInsured" class="single" class="js-states form-control">
                                        <option value="">Select Company</option>
                                        <option value="21st centtury Insurance">21st centtury Insurance</option>
                                        <option value="AAA Insurance Co.">AAA Insurance Co.</option>
                                        <option value="Allstate">Allstate</option>
                                        <option value="American Family">American Family</option>
                                        <option value="AMICA">AMICA</option>
                                        <option value="Country Financial">Country Financial</option>
                                        <option value="Esurance">Esurance</option>
                                        <option value="Farmers">Farmers</option>
                                        <option value="Geico">Geico</option>
                                        <option value="Liberty Mutual">Liberty Mutual</option>
                                        <option value="Mercury">Mercury</option>
                                        <option value="Metlife">Metlife</option>
                                        <option value="Nationwide">Nationwide</option>
                                        <option value="Progressive">Progressive</option>
                                        <option value="Safeco">Safeco</option>
                                        <option value="State Farm">State Farm</option>
                                        <option value="The Hartford">The Hartford</option>
                                        <option value="Travelers">Travelers</option>
                                        <option value="USAA">USAA</option>
                                        <option value="Other">Other</option>
                                    </select> 
                                    <span class="err" id="err-namedInsured">Required</span>
                                </div>
                                <div class="col-6">
                                  <label class="fieldlabels">YOUR CURRENT LIABILITY LIMITS</label>
                                    <select id="liability" name="liability" class="single" class="js-states form-control">
                                        <option value="">Current Liability</option>
                                        <option value="25/20/50">25/20/50</option>
                                        <option value="25/20/50">25/20/25</option>
                                        <option value="50/100/25">50/100/25</option>
                                        <option value="50/100/50">50/100/50</option>
                                        <option value="100/300/50">100/300/50</option>
                                        <option value="100/300/100">100/300/100</option>
                                        <option value="250/500/100">250/500/100</option>
                                        <option value="250/500/250">250/500/250</option>
                                        <option value="500/500/300">500/500/300</option>
                                        <option value="500/500/500">500/500/500</option>
                                        <option value="1000/1000/500">1000/1000/500</option>
                                        <option value="1000/1000/1000">1000/1000/1000</option>
                                        <option value="100 CSL">100 CSL</option>
                                        <option value="300 CSL">300 CSL</option>
                                        <option value="500 CSL">500 CSL</option>
                                    </select>
                                    <span class="err" id="err-liability">Required</span>   
                                </div>
                            </div>
                            <div class="primaryUse commuteDistance cu_insured">
                                <label class="fieldlabels">YOUR CURRENT COMPREHENSIVE / COLLISION</label>
                                <div>
                                    <input type="radio" id="coverage_0" name="coverage" value="Full Coverage">
                                    <label for="coverage_0">Full Coverage</label>
                                </div>
                                <div>
                                    <input type="radio" id="coverage_1" name="coverage" value="No Coverage">
                                    <label for="coverage_1">No Coverage</label>
                                </div>
                                <p>
                                    <span class="err" id="err-coverage">Required</span> 
                                </p>
                            </div>
                        </div>
                        <input id="fifth-step" type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 4th Step -->
                    <!-- Start 5th Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 5 - 8</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse">
                            <label class="fieldlabels" id="gender">Gender</label>
                            <div class="male">
                                <input type="radio" name="gender" id="gender_0" value="Male">
                                <label for="gender_0"><i class="fas fa-male"></i>Male</label>
                            </div>
                            <div class="female">
                                <input type="radio" name="gender" id="gender_1" value="Female">
                                <label for="gender_1"><i class="fas fa-female"></i>Female</label>
                            </div>
                            <p>
                                <span class="err" id="err-gender">Required</span> 
                            </p>
                        </div>
                        <div class="primaryUse have_veh">
                            <label id="maritalStatus" class="fieldlabels">Marital Status</label>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_0" value="Single">
                                <label class="ng-tns-c3-147" for="maritalStatus_0">Single (never married)</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_1" value="Married">
                                <label class="ng-tns-c3-147" for="maritalStatus_1">Married</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_2" value="Divorced">
                                <label class="ng-tns-c3-147" for="maritalStatus_2">Divorced</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_3" value="Widowed"> 
                                <label class="ng-tns-c3-147" for="maritalStatus_3">Widowed</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_4" value="Civil Union">
                                <label class="ng-tns-c3-147" for="maritalStatus_4">Civil Union</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_5" value="Separated">
                                <label class="ng-tns-c3-147" for="maritalStatus_5">Separated</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_6" value="Domestic Partner">
                                <label class="ng-tns-c3-147" for="maritalStatus_6">Domestic Partner</label>
                            </div>
                            <p>
                                <span class="err" id="err-maritalStatus">Required</span> 
                            </p>
                        </div>
                        <input id="sixth-step" type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 5th Step -->
                    <!-- Start 6th Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 6 - 8</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row" >
                            <div class="col-6">
                              <label class="fieldlabels">Education Level</label> 
                                <select id="educationLevel" name="educationLevel" class="single" class="js-states form-control">
                                    <option value="">Education Level</option>
                                    <option value="No high school diploma or GED">No high school diploma or GED</option>
                                    <option value="High school diploma or GED">High school diploma or GED</option>
                                    <option value="Vocation/technical degree">Vocation/technical degree</option>
                                    <option value="Completed some college no degree">Completed some college no degree</option>
                                    <option value="Bachelors Degree">Bachelors Degree</option>
                                    <option value="Masters Degree">Masters Degree</option>
                                    <option value="PHD/Doctorate">PHD/Doctorate</option>
                                    <option value="Medical Degree">Medical Degree</option>
                                    <option value="Law Degree">Law Degree</option>
                                    <option value="Associates Degree">Associates Degree</option>
                                </select>
                                <span class="err" id="err-educationLevel">Required</span>   
                            </div>
                            <div class="col-6">
                              <label class="fieldlabels">Occupation</label>
                                <select id="occupation" name="occupation" class="single" class="js-states form-control">
                                    <option value="">Select Occupation</option>
                                    <option value="Homemakers(full-time)">Homemakers(full-time)</option>
                                    <option value="Retired(full-time)">Retired(full-time)</option>
                                    <option value="Unemployed">Unemployed</option>
                                    <option value="Student(full-time)">Student(full-time)</option>
                                    <option value="Agriculture/Forestry/Fishing">Agriculture/Forestry/Fishing</option>
                                    <option value="Legal/Law Enforcement/Security">Legal/Law Enforcement/Security</option>
                                    <option value="Medical/Social Services/Religion">Medical/Social Services/Religion</option>
                                    <option value="Presonal Care/Service">Presonal Care/Service</option>
                                    <option value="Production/Manufacturing">Production/Manufacturing</option>
                                    <option value="Repair/Maintenance/Grounds">Repair/Maintenance/Grounds</option>
                                    <option value="Art/Design/Media">Art/Design/Media</option>
                                    <option value="Banking/Finance/Real Estate">Banking/Finance/Real Estate</option>
                                    <option value="Business/Sales/Office">Business/Sales/Office</option>
                                    <option value="Construction/Enrgy/Mining">Construction/Enrgy/Mining</option>
                                    <option value="Education/Library">Education/Library</option>
                                    <option value="Sports/Recreation">Sports/Recreation</option>
                                    <option value="Travel/Transportation/Storage">Travel/Transportation/Storage</option>
                                    <option value="Engineer/Architect/Science/Math">Engineer/Architect/Science/Math</option>
                                    <option value="Food Service/Hitel Service">Food Service/Hitel Service</option>
                                    <option value="Government/Military">Government/Military</option>
                                    <option value="Information Technology">Information Technology</option>
                                    <option value="Insurance">Insurance</option>
                                </select>
                                <span class="err" id="err-occupation">Required</span>  
                            </div>
                        </div>
                        <div class="primaryUse commuteDistance own_lease">
                            <label class="fieldlabels" id="own_lease">Own Or Rent House</label>
                            <div>
                                <input type="radio" id="Own" name="ownRent" value="Own">
                                <label for="Own">Own</label>
                            </div>
                            <div>
                                <input type="radio" id="Rent" name="ownRent" value="Rent">
                                <label for="Rent">Rent</label>
                            </div>
                            <p>
                                <span class="err" id="err-ownRent">Required</span> 
                            </p>
                        </div>
                        <div class="primaryUse commuteDistance own_lease">
                            <label class="fieldlabels" id="own_lease">License Status</label>
                            <div>
                                <input type="radio" id="Valid" name="LicenseStatus" value="Valid">
                                <label for="Valid">Valid</label>
                            </div>
                            <div>
                                <input type="radio" id="Suspended" name="LicenseStatus" value="Suspended">
                                <label for="Suspended">Suspended</label>
                            </div>
                            <div>
                                <input type="radio" id="Revoked" name="LicenseStatus" value="Revoked">
                                <label for="Revoked">Revoked</label>
                            </div>
                            <div>
                                <input type="radio" id="Expired" name="LicenseStatus" value="Expired">
                                <label for="Expired">Expired</label>
                            </div>
                            <p>
                                <span class="err" id="err-LicenseStatus">Required</span> 
                            </p>
                        </div>
                        <input id="sevnth-step" type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 6th Step -->
                    <!-- Start 7th Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 7 - 8</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse commuteDistance own_lease">
                            <label class="fieldlabels">Are you required to have an SR-22 or other Financial Responsibility document?</label>
                            <div>
                                <input type="radio" id="SR_22_doc_0" name="SR_22_doc" value="YES">
                                <label for="SR_22_doc_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="SR_22_doc_1" name="SR_22_doc" value="NO">
                                <label for="SR_22_doc_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-SR_22_doc">Required</span>
                            </p>
                        </div>
                        <div class="primaryUse commuteDistance own_lease">
                            <label class="fieldlabels">Any at –fault accidents in the last 3 years?</label>
                            <div>
                                <input type="radio" id="faultAccidents_0" name="faultAccidents" value="YES">
                                <label for="faultAccidents_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="faultAccidents_1" name="faultAccidents" value="NO">
                                <label for="faultAccidents_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-faultAccidents">Required</span>
                            </p>
                        </div>
                        <div class="primaryUse commuteDistance own_lease">
                            <label class="fieldlabels">Have You had a PIP Accident in the last 5 Years?</label>
                            <div>
                                <input type="radio" id="PIPAccident_0" name="PIPAccident" value="YES">
                                <label for="PIPAccident_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="PIPAccident_1" name="PIPAccident" value="NO">
                                <label for="PIPAccident_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-PIPAccident">Required</span>
                            </p>
                        </div>
                        <input id="first_step" type="button" name="next" class="next action-button" value="Next" />
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 7th Step -->
                    <!-- Start 8th Step -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 8 - 8</h2>
                                </div>
                            </div>
                            <div>
                                <label class="fieldlabels">First Name</label> 
                                <input id="fname" type="text" name="fname" placeholder="First Name" />
                                <span class="err" id="err-fname">Required</span>   
                            </div>
                            <div>
                               <label class="fieldlabels">Last Name</label> 
                                <input id="lname" type="text" name="lname" placeholder="Last Name" />
                                <span class="err" id="err-lname">Required</span>  
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">Email</label> 
                                    <input id="email" type="email" name="email" placeholder="Enter Your email" />
                                    <span class="err" id="err-email">Required</span> 
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">Phone</label> 
                                    <input id="tel" type="tel" name="phone" placeholder="Enter Your contact number" />
                                    <span class="err" id="err-tel">Required</span> 
                                </div>
                            </div>
                            <div>
                                <label class="fieldlabels">DOB</label> 
                                <input id="dob" type="date" name="DOB" placeholder="mm/dd/yy" />
                                <span class="err" id="err-dob">Required</span>
                            </div>
                            <div>
                                <label class="fieldlabels">Adress</label> 
                                <input id="adress" type="adress" name="adress" placeholder="Enter Your Adress" />
                                <span class="err" id="err-adress">Required</span>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">City</label> 
                                    <input id="city" type="text" name="city" placeholder="Enter Your city" /> 
                                    <span class="err" id="err-city">Required</span>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">State</label> 
                                    <input id="state" type="text" name="state" placeholder="Enter Your state" />
                                    <span class="err" id="err-state">Required</span> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <label class="fieldlabels">Zip</label> 
                                    <input id="zip" type="text" name="zip" placeholder="Enter Zip Code" />
                                    <span class="err" id="err-zip">Required</span>
                                </div>
                            </div>
                        </div>
                        <input id="btnsubmit" type="submit" name="submit" value="Submit" class="next action-button"/> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- End 8th Step -->

                    <!-- Start 9th Step -->
                    <fieldset>
                        <div>
                            <h1>Thank You</h1>
                            <div id="msgSubmit"></div>
                        </div>
                    </fieldset>
                    <!-- End 9th Step -->

                </form>
            </div>
        </div>
    </div>
</div>
</div>
<div class="thankyou-call-us">
    <div class="ast-container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="thankyou-call-us-heading-title">Call US</h3>
                <span class="thankyou-call-us-divider-separator"></span>
                <p class="thankyou-call-us-text">Feel free to give us a call directly to be a connected with a covered advisor</p>
                <a href="tel:+923334415875" class="thankyou-call-us-cta" role="button">Call Now</span></a>
            </div>
            <div class="col-md-6">
                <h3 class="thankyou-call-us-heading-title">SCHEDULE A CALL</h3>
                <span class="thankyou-call-us-divider-separator"></span>
                <p class="thankyou-call-us-text">If you are busy, schedule a call below and a covered advisor will call you</p>
                <a href="https://calendly.com/willmorefrancis" target="_blank" class="thankyou-call-us-cta" role="button">Schedule a Call</span></a>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.0/circle-progress.min.js'></script>
<script type="text/javascript">
$(document).ready(function(){
    jQuery('.err').hide();
    var errStatus;
    // validation for 1st step
    jQuery('#first_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if(jQuery("input[name='SR_22_doc']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-SR_22_doc').show();
        }
        if(jQuery("input[name='faultAccidents']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-faultAccidents').show();
        }
        if(jQuery("input[name='PIPAccident']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-PIPAccident').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });

    //validation 2nd step
    jQuery('#scnd_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#years").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-years').show();
        }
        if( jQuery("#makes").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-makes').show();
        }
        if( jQuery("#models").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-models').show();
        }
        if( jQuery("#vinnumber").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-vinnumber').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });

    //validation 3rd step
    jQuery('#third_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if(jQuery("input[name='primaryVehicleUse']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-primaryVehicleUse').show();
        }
        if(jQuery("input[name='commuteDistance']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-commuteDistance').show();
        }
        if(jQuery("input[name='work_sch']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-work_sch').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });

    //validation 4th step
    jQuery('#forth-step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if(jQuery("input[name='ownLease']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-ownLease').show();
        }
        if (jQuery("input[name='ownLease']:checked").val() == 'Own') {
            if(jQuery("input[name='makePay']:checked").val()) {} else {
               errStatus = 1;
               jQuery('#err-makePay').show();
            }
        }
        if(jQuery("input[name='have_veh']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-have_veh').show();
        }
        if(jQuery("input[name='ride_shr']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-ride_shr').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });


    //validation 5th step
    jQuery('#fifth-step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if(jQuery("input[name='cu_insured']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-cu_insured').show();
        }
        if (jQuery("input[name='cu_insured']:checked").val() == 'Yes') {
            if( jQuery("#namedInsured").val().length > 1 ) {} else {
               errStatus = 1;
               jQuery('#err-namedInsured').show();
            }
            if( jQuery("#liability").val().length > 1 ) {} else {
               errStatus = 1;
               jQuery('#err-liability').show();
            }
            if(jQuery("input[name='coverage']:checked").val()) {} else {
               errStatus = 1;
               jQuery('#err-coverage').show();
            }
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });

    //validation 6th step
    jQuery('#sixth-step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if(jQuery("input[name='gender']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-gender').show();
        }
        if(jQuery("input[name='maritalStatus']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-maritalStatus').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });


    //validation 7th step
    jQuery('#sevnth-step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if( jQuery("#educationLevel").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-educationLevel').show();
        }
        if( jQuery("#occupation").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-occupation').show();
        }
        if(jQuery("input[name='ownRent']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-ownRent').show();
        }
        if(jQuery("input[name='LicenseStatus']:checked").val()) {} else {
           errStatus = 1;
           jQuery('#err-LicenseStatus').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
        }
    });

    //final step submit
    jQuery('#btnsubmit').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        var email = jQuery("#email").val();
        if( IsEmail(email) ) {} else {
           errStatus = 1;
           jQuery('#err-email').show();
        }
        if( jQuery("#tel").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-tel').show();
        }
        if( jQuery("#fname").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-fname').show();
        }
        if( jQuery("#lname").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-lname').show();
        }
        if( jQuery("#dob").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-dob').show();
        }
        if( jQuery("#adress").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-adress').show();
        }
        if( jQuery("#city").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-city').show();
        }
        if( jQuery("#state").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-state').show();
        }
        if( jQuery("#zip").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-zip').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
          submitForm()
        }
    });


    var current_fs, next_fs, previous_fs, btn; //fieldsets
    var opacity;
    var current = 1;
    var steps = $("fieldset").length;

    Circlle('.round', current);
    $('.next').click(function(){
        if (errStatus == 0) {
            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            //Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            Circlle('.round', ++current);
            $("html, body").animate({ scrollTop: "0" });
        }
    });

    $(".previous").click(function(){

        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();

        //Remove class active
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

        //show the previous fieldset
        previous_fs.show();

        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function(now) {
                // for making fielset appear animation
                opacity = 1 - now;

                current_fs.css({
                    'display': 'none',
                    'position': 'relative'
                });
                previous_fs.css({'opacity': opacity});
            },
            duration: 500
        });
        Circlle('.round', --current);
        $("html, body").animate({ scrollTop: "0" });
    });
    function Circlle(el, curStep){
        var percent = parseFloat(1 / steps) * curStep;
            percentval = percent.toFixed(2);
            $('.round').attr('data-value', percentval);
            $(el).circleProgress({value: percent, fill: {color: '#054f93'}}).on('circle-animation-progress', function(event, progress, stepValue){
                if(percent < 1 ){
                    $(this).find('strong').text(String(percent.toFixed(2)).substr(2)+'%');
                }else{
                    $(this).find('strong').text('100%');
                }
            });  
    };

    $(".submit").click(function(){
        return false;
    })

    // name value update on api section
    // $( 'input[name="fname"]' )
    //     .keyup(function() {
    //     var value = $( this ).val();
    //     $( '#car-info-txt' ).text('Hello '+value+' what is the auto info?');
    // }).keyup();


    // select 2 plugin code
    $(".single").select2({
    });

    // start api call section js

    // disable modals and makes options
    $('#makes').prop('disabled', 'disabled');
    $('#models').prop('disabled', 'disabled');

    // get years and append in options
    var url = "https://vehapi.com/api/v1/car-lists/get/car/years";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);

    xhr.setRequestHeader("Accept", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer BXkQoaJ9vLVRZvaLxSCqznL45veElwvAevIsfHiB");

    xhr.onreadystatechange = function () {
       if (xhr.readyState === 4) {
          var obj = JSON.parse(xhr.responseText);
          var options;
          options += '<option value="">Select Year</option>';
            for (var i = 0; i < obj.length; i++) {
               options += '<option value="'+obj[i]['year']+'">'+obj[i]['year']+'</option>';
            }
            $( "#years" ).html( options );
       }};
    xhr.send();

    // on year change get makes
    $('#years').change(function(){
        $('#makes').prop('disabled', false);
        year = $(this).val();
        var url = "https://vehapi.com/api/v1/car-lists/get/car/makes/"+year;
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);

        xhr.setRequestHeader("Accept", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer BXkQoaJ9vLVRZvaLxSCqznL45veElwvAevIsfHiB");

        xhr.onreadystatechange = function () {
           if (xhr.readyState === 4) {
                var obj = JSON.parse(xhr.responseText);
                options1 = '';
                options1 += '<option value="">Select Make</option>';
                for (var i = 0; i < obj.length; i++) {
                    options1 += '<option value="'+obj[i]['make']+'">'+obj[i]['make']+'</option>';
                }
                $( "#makes" ).html( options1 );
           }};
        xhr.send();
    });

    // on makes change get models
    $('#makes').change(function(){
        $('#models').prop('disabled', false);
        makes = $(this).val();
        var url = "https://vehapi.com/api/v1/car-lists/get/all/car/models/"+makes;
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);

        xhr.setRequestHeader("Accept", "application/json");
        xhr.setRequestHeader("Authorization", "Bearer BXkQoaJ9vLVRZvaLxSCqznL45veElwvAevIsfHiB");

        xhr.onreadystatechange = function () {
           if (xhr.readyState === 4) {
                var obj = JSON.parse(xhr.responseText);
                options2 = '';
                options2 += '<option value="">Select Model</option>';
                for (var i = 0; i < obj.length; i++) {
                    options2 += '<option value="'+obj[i]['model']+'">'+obj[i]['model']+'</option>'; 
                }
                $( "#models" ).html( options2 );
           }};
        xhr.send();
    });

    // on radio option select add class
    $(function() {
        var $radioButtons = $('input[type="radio"]');
        $radioButtons.click(function() {
            $radioButtons.each(function() {
                $(this).parent().toggleClass('selected', this.checked);
            });
        });
    });

    //check lease own value and show hide payments question
    $("input[name=ownLease]").on('change', function(){
        $(".make_pay")[this.id =='Own'?'slideDown':'slideUp']();
    });
    $("input[name=cu_insured]").on('change', function(){
        $("#insured_named")[this.id =='Yes'?'slideDown':'slideUp']();
    });
});




function submitForm(){
    var fname = jQuery("#fname").val();
    var lname = jQuery("#lname").val();
    var email = jQuery("#email").val();
    var phone = jQuery("#tel").val();
    var adress = jQuery("#adress").val();
    var DOB = jQuery("#dob").val();
    var city = jQuery("#city").val();
    var state = jQuery("#state").val();
    var zip = jQuery("#zip").val();
    var autoYear = jQuery("#years").val();
    var autoMake = jQuery("#makes").val();
    var autoModal = jQuery("#models").val();
    var vinnumbr = jQuery("#vinnumber").val();
    var primaryVehicleUse = jQuery("input[name='primaryVehicleUse']:checked").val();
    var commuteDistance = jQuery("input[name='commuteDistance']:checked").val();
    var work_sch = jQuery("input[name='work_sch']:checked").val();
    var ownLease = jQuery("input[name='ownLease']:checked").val();
    var makePay = jQuery("input[name='makePay']:checked").val();
    var have_veh = jQuery("input[name='have_veh']:checked").val();
    var ride_shr = jQuery("input[name='ride_shr']:checked").val();
    var cu_insured = jQuery("input[name='cu_insured']:checked").val();
    var namedInsured = jQuery("#namedInsured").val();
    var liability = jQuery("#liability").val();
    var coverage = jQuery("input[name='coverage']:checked").val();
    var gender = jQuery("input[name='gender']:checked").val();
    var maritalStatus = jQuery("input[name='maritalStatus']:checked").val();
    var educationLevel = jQuery("#educationLevel").val();
    var occupation = jQuery("#occupation").val();
    var ownRent = jQuery("input[name='ownRent']:checked").val();
    var LicenseStatus = jQuery("input[name='LicenseStatus']:checked").val();
    var SR_22_doc = jQuery("input[name='SR_22_doc']:checked").val();
    var faultAccidents = jQuery("input[name='faultAccidents']:checked").val();
    var PIPAccident = jQuery("input[name='PIPAccident']:checked").val();
    jQuery.ajax({
        type: "POST",
        url: "/wp-content/themes/astra/assets/php/cars-form-process.php",
        data: {
                fname : fname,
                lname : lname,
                email : email,
                phone : phone,
                adress : adress,
                DOB : DOB,
                city : city,
                state : state,
                zip : zip,
                autoYear : autoYear,
                autoMake : autoMake,
                autoModal : autoModal,
                vinnumbr : vinnumbr,
                primaryVehicleUse : primaryVehicleUse,
                commuteDistance : commuteDistance,
                work_sch : work_sch,
                ownLease : ownLease,
                makePay : makePay,
                have_veh : have_veh,
                ride_shr : ride_shr,
                cu_insured : cu_insured,
                namedInsured : namedInsured,
                liability : liability,
                coverage : coverage,
                gender : gender,
                maritalStatus : maritalStatus,
                educationLevel : educationLevel,
                occupation : occupation,
                ownRent : ownRent,
                LicenseStatus : LicenseStatus,
                SR_22_doc : SR_22_doc,
                faultAccidents : faultAccidents,
                PIPAccident : PIPAccident,
            },
        success : function(text){
            if (text == "success"){
                formSuccess();
            } else {
                submitMSG(false,text);
            }
        }
    });
}

function formSuccess(){
    jQuery("#msform")[0].reset();
    submitMSG(true, "Success! Your message has been sent.");
    jQuery('.thankyou-call-us').slideDown('slow');
}

function submitMSG(valid, msg){
    if(valid){
        var msgClasses = " tada text-success";
    } else {
        var msgClasses = " text-danger";
    }
    jQuery("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
}

function IsEmail(email) {
   var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
   if(!regex.test(email)) {
     return false;
   }else{
     return true;
   }
}

//inputs validations global function
function setInputFilter(textbox, inputFilter) {
  ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
    textbox.addEventListener(event, function() {
      if (inputFilter(this.value)) {
        this.oldValue = this.value;
        this.oldSelectionStart = this.selectionStart;
        this.oldSelectionEnd = this.selectionEnd;
      } else if (this.hasOwnProperty("oldValue")) {
        this.value = this.oldValue;
        this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
      } else {
        this.value = "";
      }
    });
  });
}

// Install input filters.
setInputFilter(document.getElementById("zip"), function(value) {
  return /^-?\d*$/.test(value); 
});
</script>

<?php get_footer(); ?>