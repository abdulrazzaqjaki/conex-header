<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

define('WP_USE_THEMES', false);
require('../../../../../wp-blog-header.php');
if ( ! is_admin() ) {
    require_once( ABSPATH . 'wp-admin/includes/post.php' );
}
global $wpdb;
$table_name = $wpdb->prefix.'home_forms_data';
// echo $table_name;
// Create table to store forms data
if (!function_exists('maybe_create_table')) {
    require_once ABSPATH . '/wp-admin/install-helper.php';
}

//check if table is not exist then create this table
if ($wpdb->get_var("SHOW TABLES LIKE '" . $table_name . "'") != $table_name) {
    $create_ddl = "CREATE TABLE $table_name (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        fname VARCHAR(255) NOT NULL,
        lname VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(255) NOT NULL,
        adress VARCHAR(255) NOT NULL,
        DOB VARCHAR(255) NOT NULL,
        city VARCHAR(255) NOT NULL,
        state VARCHAR(255) NOT NULL,
        zip VARCHAR(255) NOT NULL,
        home VARCHAR(255) NOT NULL,
        property_address VARCHAR(255) NOT NULL,
        unit VARCHAR(255) NOT NULL,
        vinnumbr VARCHAR(255) NOT NULL,
        occupancy VARCHAR(255) NOT NULL,
        primary_home VARCHAR(255) NOT NULL,
        use_property VARCHAR(255) NOT NULL,
        year_built VARCHAR(255) NOT NULL,
        square_feet VARCHAR(255) NOT NULL,
        construction_type VARCHAR(255) NOT NULL,
        roof_type VARCHAR(255) NOT NULL,
        roof_shape VARCHAR(255) NOT NULL,
        number_of_rooms VARCHAR(255) NOT NULL,
        number_of_stories VARCHAR(255) NOT NULL,
        contents VARCHAR(255) NOT NULL,
        liability_limits VARCHAR(255) NOT NULL,
        medical_payments VARCHAR(255) NOT NULL,
        residence_passed VARCHAR(255) NOT NULL,
        insurance_claims VARCHAR(255) NOT NULL,
        type_of_loss VARCHAR(255) NOT NULL,
        paid_by_carrier VARCHAR(255) NOT NULL,
        date_of_occurance VARCHAR(255) NOT NULL,
        have_any_pets VARCHAR(255) NOT NULL,
        gated_community VARCHAR(255) NOT NULL,
        burglar_alarm VARCHAR(255) NOT NULL,
        roof_replaced VARCHAR(255) NOT NULL,
        roof_replaced_year VARCHAR(255) NOT NULL,
        built_over_sand VARCHAR(255) NOT NULL,
        built_over_water VARCHAR(255) NOT NULL,
        roof_year VARCHAR(255) NOT NULL,
        electrical_year VARCHAR(255) NOT NULL,
        plumbing_year VARCHAR(255) NOT NULL,
        heating_year VARCHAR(255) NOT NULL,
        sinkhole_activity VARCHAR(255) NOT NULL,
        swimming_pool VARCHAR(255) NOT NULL,
        swimming_pool_ground VARCHAR(255) NOT NULL,
        swimming_pool_foundation VARCHAR(255) NOT NULL,
        house_frame VARCHAR(255) NOT NULL,
        primary_heating VARCHAR(255) NOT NULL,
        hydrant_feet VARCHAR(255) NOT NULL,
        fire_station VARCHAR(255) NOT NULL,
        flood_zone VARCHAR(255) NOT NULL,
        cu_insured VARCHAR(255) NOT NULL,
        namedInsured VARCHAR(255) NOT NULL,
        gender VARCHAR(255) NOT NULL,
        maritalStatus VARCHAR(255) NOT NULL,
        educationLevel VARCHAR(255) NOT NULL,
        occupation VARCHAR(255) NOT NULL,
        ownRent VARCHAR(255) NOT NULL,
        LicenseStatus VARCHAR(255) NOT NULL,
        suspended VARCHAR(255) NOT NULL,
        faultAccidents VARCHAR(255) NOT NULL, 
        created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
    $result = maybe_create_table($table_name, $create_ddl);
}
$errorMSG1 = '';
//first name
if (empty($_POST["fname"])) {
    $fname = '';
} else {
    $fname = stripslashes($_POST["fname"]);
}
//last name
if (empty($_POST["lname"])) {
    $lname = '';
} else {
    $lname = stripslashes($_POST["lname"]);
}
//adress
if (empty($_POST["adress"])) {
    $adress = '';
} else {
    $adress = stripslashes($_POST["adress"]);
}
//DOB
if (empty($_POST["DOB"])) {
    $DOB = '';
} else {
    $DOB = stripslashes($_POST["DOB"]);
}
//city
if (empty($_POST["city"])) {
    $city = '';
} else {
    $city = stripslashes($_POST["city"]);
}
//state
if (empty($_POST["state"])) {
    $state = '';
} else {
    $state = stripslashes($_POST["state"]);
}
//zip
if (empty($_POST["zip"])) {
    $zip = '';
} else {
    $zip = stripslashes($_POST["zip"]);
}
//Select the Style of Your Home
if (empty($_POST["home"])) {
    $home = '';
} else {
    $home = stripslashes($_POST["home"]);
}
//Property Address
if (empty($_POST["property_address"])) {
    $property_address = '';
} else {
    $property_address = stripslashes($_POST["property_address"]);
}
//unit
if (empty($_POST["unit"])) {
    $unit = '';
} else {
    $unit = stripslashes($_POST["unit"]);
}

//VIN Number
if (empty($_POST["vinnumbr"])) {
    $vinnumbr = '';
} else {
    $vinnumbr = stripslashes($_POST["vinnumbr"]);
}

//Occupancy?
if (empty($_POST["occupancy"])) {
    $occupancy = '';
} else {
    $occupancy = stripslashes($_POST["occupancy"]);
}

//Is this your primary home?
if (empty($_POST["primary_home"])) {
    $primary_home = '';
} else {
    $primary_home = stripslashes($_POST["primary_home"]);
}

//Use of the property:
if (empty($_POST["use_of_the_property"])) {
    $use_property = '';
} else {
    $use_property = stripslashes($_POST["use_of_the_property"]);
}

//Year Built
if (empty($_POST["year_built"])) {
    $year_built = '';
} else {
    $year_built = stripslashes($_POST["year_built"]);
}

//Square Feet
if (empty($_POST["square_feet"])) {
    $square_feet = '';
} else {
    $square_feet = stripslashes($_POST["square_feet"]);
}

//Construction Type
if (empty($_POST["construction_type"])) {
    $construction_type = '';
} else {
    $construction_type = stripslashes($_POST["construction_type"]);
}

//Roof Type
if (empty($_POST["roof_type"])) {
    $roof_type = '';
} else {
    $roof_type = stripslashes($_POST["roof_type"]);
}

//Roof Shape
if (empty($_POST["roof_shape"])) {
    $roof_shape = '';
} else {
    $roof_shape = stripslashes($_POST["roof_shape"]);
}

//How many rooms?
if (empty($_POST["number_of_rooms"])) {
    $number_of_rooms = '';
} else {
    $number_of_rooms = stripslashes($_POST["number_of_rooms"]);
}

//Number of stories
if (empty($_POST["number_of_stories"])) {
    $number_of_stories = '';
} else {
    $number_of_stories = stripslashes($_POST["number_of_stories"]);
}

//Contents
if (empty($_POST["contents"])) {
    $contents = '';
} else {
    $contents = stripslashes($_POST["contents"]);
}

//Liability limits
if (empty($_POST["liability_limits"])) {
    $liability_limits = '';
} else {
    $liability_limits = stripslashes($_POST["liability_limits"]);
}

//Medical payments
if (empty($_POST["medical_payments"])) {
    $medical_payments = '';
} else {
    $medical_payments = stripslashes($_POST["medical_payments"]);
}

//Any residence of the house has passed or has of the following
if (empty($_POST["residence_passed"])) {
    $residence_passed = '';
} else {
    $residence_passed = stripslashes($_POST["residence_passed"]);
}

//Insurance claims?
if (empty($_POST["insurance_claims"])) {
    $insurance_claims = '';
} else {
    $insurance_claims = stripslashes($_POST["insurance_claims"]);
}

//Description type of loss
if (empty($_POST["type_of_loss"])) {
    $type_of_loss = '';
} else {
    $type_of_loss = stripslashes($_POST["type_of_loss"]);
}

//Amount Paid by Carrier
if (empty($_POST["paid_by_carrier"])) {
    $paid_by_carrier = '';
} else {
    $paid_by_carrier = stripslashes($_POST["paid_by_carrier"]);
}

//Date Of Occurance
if (empty($_POST["date_of_occurance"])) {
    $date_of_occurance = '';
} else {
    $date_of_occurance = stripslashes($_POST["date_of_occurance"]);
}

//Do you have any pets?
if (empty($_POST["have_any_pets"])) {
    $have_any_pets = '';
} else {
    $have_any_pets = stripslashes($_POST["have_any_pets"]);
}

//Gated Community
if (empty($_POST["gated_community"])) {
    $gated_community = '';
} else {
    $gated_community = stripslashes($_POST["gated_community"]);
}

//Burglar Alarm
if (empty($_POST["burglar_alarm"])) {
    $burglar_alarm = '';
} else {
    $burglar_alarm = stripslashes($_POST["burglar_alarm"]);
}

//Has your roof been replaced?
if (empty($_POST["roof_replaced"])) {
    $roof_replaced = '';
} else {
    $roof_replaced = stripslashes($_POST["roof_replaced"]);
}

//What Year?
if (empty($_POST["roof_replaced_year"])) {
    $roof_replaced_year = '';
} else {
    $roof_replaced_year = stripslashes($_POST["roof_replaced_year"]);
}

//Built over sand?
if (empty($_POST["built_over_sand"])) {
    $built_over_sand = '';
} else {
    $built_over_sand = stripslashes($_POST["built_over_sand"]);
}

//Built over water?
if (empty($_POST["built_over_water"])) {
    $built_over_water = '';
} else {
    $built_over_water = stripslashes($_POST["built_over_water"]);
}

//In what year were these systems repaired:
//Roof Year
if (empty($_POST["roof_year"])) {
    $roof_year = '';
} else {
    $roof_year = stripslashes($_POST["roof_year"]);
}

//Electrical Year
if (empty($_POST["electrical_year"])) {
    $electrical_year = '';
} else {
    $electrical_year = stripslashes($_POST["electrical_year"]);
}

//Plumbing Year
if (empty($_POST["plumbing_year"])) {
    $plumbing_year = '';
} else {
    $plumbing_year = stripslashes($_POST["plumbing_year"]);
}

//Heating Year
if (empty($_POST["heating_year"])) {
    $heating_year = '';
} else {
    $heating_year = stripslashes($_POST["heating_year"]);
}

//Sinkhole activity?
if (empty($_POST["sinkhole_activity"])) {
    $sinkhole_activity = '';
} else {
    $sinkhole_activity = stripslashes($_POST["sinkhole_activity"]);
}

//Swimming Pool?
if (empty($_POST["swimming_pool"])) {
    $swimming_pool = '';
} else {
    $swimming_pool = stripslashes($_POST["swimming_pool"]);
}

//Swimming Pool Ground?
if (empty($_POST["swimming_pool_ground"])) {
    $swimming_pool_ground = '';
} else {
    $swimming_pool_ground = stripslashes($_POST["swimming_pool_ground"]);
}

//What type of foundation?
if (empty($_POST["swimming_pool_foundation"])) {
    $swimming_pool_foundation = '';
} else {
    $swimming_pool_foundation = stripslashes($_POST["swimming_pool_foundation"]);
}

//Frame of the house?
if (empty($_POST["house_frame"])) {
    $house_frame = '';
} else {
    $house_frame = stripslashes($_POST["house_frame"]);
}

//Home’s primary heating?
if (empty($_POST["primary_heating"])) {
    $primary_heating = '';
} else {
    $primary_heating = stripslashes($_POST["primary_heating"]);
}

//Hydrant within 1,000 feet?
if (empty($_POST["hydrant_feet"])) {
    $hydrant_feet = '';
} else {
    $hydrant_feet = stripslashes($_POST["hydrant_feet"]);
}

//Nearest fire station?
if (empty($_POST["fire_station"])) {
    $fire_station = '';
} else {
    $fire_station = stripslashes($_POST["fire_station"]);
}

//Flood Zone
if (empty($_POST["flood_zone"])) {
    $flood_zone = '';
} else {
    $flood_zone = stripslashes($_POST["flood_zone"]);
}

//Currently Insured?
if (empty($_POST["cu_insured"])) {
    $cu_insured = '';
} else {
    $cu_insured = stripslashes($_POST["cu_insured"]);
}

//Named of current insurer
if (empty($_POST["namedInsured"])) {
    $namedInsured = '';
} else {
    $namedInsured = stripslashes($_POST["namedInsured"]);
}

//Gender
if (empty($_POST["gender"])) {
    $gender = '';
} else {
    $gender = stripslashes($_POST["gender"]);
}

//Marital Status
if (empty($_POST["maritalStatus"])) {
    $maritalStatus = '';
} else {
    $maritalStatus = stripslashes($_POST["maritalStatus"]);
}

//Education Level
if (empty($_POST["educationLevel"])) {
    $educationLevel = '';
} else {
    $educationLevel = stripslashes($_POST["educationLevel"]);
}

//Occupation
if (empty($_POST["occupation"])) {
    $occupation = '';
} else {
    $occupation = stripslashes($_POST["occupation"]);
}

//Own or rent house
if (empty($_POST["ownRent"])) {
    $ownRent = '';
} else {
    $ownRent = stripslashes($_POST["ownRent"]);
}

//EMAIL
if (empty($_POST["email"])) {
    $email = '';
} else {
    $email = stripslashes($_POST["email"]);
}
// MSG SUBJECT
if (empty($_POST["phone"])) {
    $phone = '';
} else {
    $phone = stripslashes($_POST["phone"]);
}

// echo 'First name:'.$fname.'<br>';
// echo 'Last name:'.$lname.'<br>';
// echo 'Email:'.$email.'<br>';
// echo 'Phone:'.$phone.'<br>';
// echo 'Adress:'.$adress.'<br>';
// echo 'DOB:'.$DOB.'<br>';
// echo 'city:'.$city.'<br>';
// echo 'state:'.$state.'<br>';
// echo 'zip:'.$zip.'<br>';
// echo 'Select the Style of Your Home:'.$home.'<br>';
// echo 'Property Address:'.$property_address.'<br>';
// echo 'unit:'.$unit.'<br>';
// echo 'VIN Number:'.$vinnumbr.'<br>';
// echo 'Occupancy:'.$occupancy.'<br>';
// echo 'Is this your primary home?:'.$primary_home.'<br>';
// echo 'Use of the property::'.$use_property.'<br>';
// echo 'Year Built:'.$year_built.'<br>';
// echo 'Square Feet:'.$square_feet.'<br>';
// echo 'Construction Type:'.$construction_type.'<br>';
// echo 'Roof Type:'.$roof_type.'<br>';
// echo 'Roof shape:'.$roof_shape.'<br>';
// echo 'How many rooms?:'.$number_of_rooms.'<br>';
// echo 'Number of stories:'.$number_of_stories.'<br>';
// echo 'Contents:'.$contents.'<br>';
// echo 'Liability limits:'.$liability_limits.'<br>';
// echo 'Medical payments:'.$medical_payments.'<br>';
// echo 'Any residence of the house has passed or has of the following:'.$residence_passed.'<br>';
// echo 'Insurance claims?'.$insurance_claims.'<br>';
// echo 'Description type of loss'.$type_of_loss.'<br>';
// echo 'Amount Paid by Carrier'.$paid_by_carrier.'<br>';
// echo 'Date Of Occurance'.$date_of_occurance.'<br>';
// echo 'Do you have any pets?'.$have_any_pets.'<br>';
// echo 'Gated Community'.$gated_community.'<br>';
// echo 'Burglar Alarm'.$burglar_alarm.'<br>';
// echo 'Has your roof been replaced?'.$roof_replaced.'<br>';
// echo 'What Year?'.$roof_replaced_year.'<br>';
// echo 'Built over sand?'.$built_over_sand.'<br>';
// echo 'Built over water?'.$built_over_water.'<br>';
// echo 'In what year were these systems repaired:'.'<br>';
// echo 'Roof Year'.$roof_year.'<br>';
// echo 'Electrical Year'.$electrical_year.'<br>';
// echo 'Plumbing Year'.$plumbing_year.'<br>';
// echo 'Heating Year'.$heating_year.'<br>';
// echo 'Sinkhole activity?'.$sinkhole_activity.'<br>';
// echo 'Swimming Pool?'.$swimming_pool.'<br>';
// echo 'Swimming Pool Ground?'.$swimming_pool_ground.'<br>';
// echo 'What type of foundation?'.$swimming_pool_foundation.'<br>';
// echo 'Frame of the house?'.$house_frame.'<br>';
// echo 'Home’s primary heating?'.$primary_heating.'<br>';
// echo 'Hydrant within 1,000 feet?'.$hydrant_feet.'<br>';
// echo 'Nearest fire station?'.$fire_station.'<br>';
// echo 'Flood Zone'.$flood_zone.'<br>';
// echo 'Currently Insured?:'.$cu_insured.'<br>';
// echo 'Named of current insurer:'.$namedInsured.'<br>';
// echo 'Gender:'.$gender.'<br>';
// echo 'Marital Status:'.$maritalStatus.'<br>';
// echo 'Education Level:'.$educationLevel.'<br>';
// echo 'Occupation:'.$occupation.'<br>';
// echo 'Own Or Rent House:'.$ownRent.'<br>';
// echo 'License Status:'.$LicenseStatus.'<br>';
// echo 'Suspended:'.$suspended.'<br>';
// echo 'Fault Accidents:'.$faultAccidents.'<br>';
$EmailTo = 'shahwal.safdar@qwertyexperts.com';
$m_Source = "ContactForm";
$Subject = "New Message From My Conextion Homes Form ";
// prepare email body text
$Body = "";
$Body .= "First name: ";
$Body .= $fname;
$Body .= "\n";
$Body .= "Last name: ";
$Body .= $lname;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $email;
$Body .= "\n";
$Body .= "Phone: ";
$Body .= $phone;
$Body .= "\n";
$Body .= "Adress: ";
$Body .= $adress;
$Body .= "\n";
$Body .= "DOB: ";
$Body .= $DOB;
$Body .= "\n";
$Body .= "City: ";
$Body .= $city;
$Body .= "\n";
$Body .= "State: ";
$Body .= $state;
$Body .= "\n";
$Body .= "Zip Code: ";
$Body .= $zip;
$Body .= "\n";
$Body .= "Select the Style of Your Home: ";
$Body .= $home;
$Body .= "\n";
$Body .= "Property Address: ";
$Body .= $property_address;
$Body .= "\n";
$Body .= "unit: ";
$Body .= $unit;
$Body .= "\n";
$Body .= "VIN Number: ";
$Body .= $vinnumbr;
$Body .= "\n";
$Body .= "Occupancy?: ";
$Body .= $occupancy;
$Body .= "\n";
$Body .= "Is this your primary home?: ";
$Body .= $primary_home;
$Body .= "\n";
$Body .= "Use of the property:: ";
$Body .= $use_property;
$Body .= "\n";
$Body .= "Year Built: ";
$Body .= $year_built;
$Body .= "\n";
$Body .= "Square Feet: ";
$Body .= $square_feet;
$Body .= "\n";
$Body .= "Construction Type: ";
$Body .= $construction_type;
$Body .= "\n";
$Body .= "Roof Type: ";
$Body .= $roof_type;
$Body .= "\n";
$Body .= "Roof shape: ";
$Body .= $roof_shape;
$Body .= "\n";
$Body .= "How many rooms?: ";
$Body .= $number_of_rooms;
$Body .= "\n";
$Body .= "Number of stories: ";
$Body .= $number_of_stories;
$Body .= "\n";
$Body .= "Contents: ";
$Body .= $contents;
$Body .= "\n";
$Body .= "Liability limits: ";
$Body .= $liability_limits;
$Body .= "\n";
$Body .= "Medical payments: ";
$Body .= $medical_payments;
$Body .= "\n";
$Body .= "Any residence of the house has passed or has of the following: ";
$Body .= $residence_passed;
$Body .= "\n";
$Body .= "Insurance claims?: ";
$Body .= $insurance_claims;
$Body .= "\n";
$Body .= "Description type of loss: ";
$Body .= $type_of_loss;
$Body .= "\n";
$Body .= "Amount Paid by Carrier: ";
$Body .= $paid_by_carrier;
$Body .= "\n";
$Body .= "Date Of Occurance: ";
$Body .= $date_of_occurance;
$Body .= "\n";
$Body .= "Do you have any pets?: ";
$Body .= $have_any_pets;
$Body .= "\n";
$Body .= "Gated Community: ";
$Body .= $gated_community;
$Body .= "\n";
$Body .= "Burglar Alarm: ";
$Body .= $burglar_alarm;
$Body .= "\n";
$Body .= "Has your roof been replaced?: ";
$Body .= $roof_replaced;
$Body .= "\n";
$Body .= "What Year?: ";
$Body .= $roof_replaced_year;
$Body .= "\n";
$Body .= "Built over sand?: ";
$Body .= $built_over_sand;
$Body .= "\n";
$Body .= "Built over water?: ";
$Body .= $built_over_water;
$Body .= "\n";
$Body .= "In what year were these systems repaired: ";
$Body .= "\n";
$Body .= "Roof Year: ";
$Body .= $roof_year;
$Body .= "\n";
$Body .= "Electrical Year: ";
$Body .= $electrical_year;
$Body .= "\n";
$Body .= "Plumbing Year: ";
$Body .= $plumbing_year;
$Body .= "\n";
$Body .= "Heating Year: ";
$Body .= $heating_year;
$Body .= "\n";
$Body .= "Sinkhole activity?: ";
$Body .= $sinkhole_activity;
$Body .= "\n";
$Body .= "Swimming Pool?: ";
$Body .= $swimming_pool;
$Body .= "\n";
$Body .= "Swimming Pool Ground?: ";
$Body .= $swimming_pool_ground;
$Body .= "\n";
$Body .= "What type of foundation?: ";
$Body .= $swimming_pool_foundation;
$Body .= "\n";
$Body .= "Frame of the house?: ";
$Body .= $house_frame;
$Body .= "\n";
$Body .= "Home’s primary heating?: ";
$Body .= $primary_heating;
$Body .= "\n";
$Body .= "Hydrant within 1,000 feet?: ";
$Body .= $hydrant_feet;
$Body .= "\n";
$Body .= "Nearest fire station?: ";
$Body .= $fire_station;
$Body .= "\n";
$Body .= "Flood Zone: ";
$Body .= $flood_zone;
$Body .= "\n";
$Body .= "Currently Insured?: ";
$Body .= $cu_insured;
$Body .= "\n";
$Body .= "Named of current insurer: ";
$Body .= $namedInsured;
$Body .= "\n";
$Body .= "Gender: ";
$Body .= $gender;
$Body .= "\n";
$Body .= "Marital Status: ";
$Body .= $maritalStatus;
$Body .= "\n";
$Body .= "Education Level: ";
$Body .= $educationLevel;
$Body .= "\n";
$Body .= "Occupation: ";
$Body .= $occupation;
$Body .= "\n";
$Body .= "Own Or Rent House: ";
$Body .= $ownRent;
$Body .= "\n";
$from = $email;
$headers = "From: " .($from) . "\r\n";
$headers .= "Reply-To: ".($from) . "\r\n";
$headers .= "Return-Path: ".($from) . "\r\n";;
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";
$headers .= "X-Priority: 3\r\n";
$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
$success = 0;
if ( mail($EmailTo,$Subject,$Body, $headers,"-f".$from."") ) {
    $success = 1;
    echo "success";
} else {
  $success = 0;
  echo "Something went wrong :(";
}


$wpdb->insert($table_name, array(
'fname' => $fname,
'lname' => $lname,
'email' => $email,
'phone' => $phone,
'adress' => $adress,
'DOB' => $DOB,
'city' => $city,
'state' => $state,
'zip' => $zip,
'home' => $home,
'property_address' => $property_address,
'unit' => $unit,
'vinnumbr' => $vinnumbr,
'occupancy' => $occupancy,
'primary_home' => $primary_home,
'use_property' => $use_property,
'year_built' => $year_built,
'square_feet' => $square_feet,
'construction_type' => $construction_type,
'roof_type' => $roof_type,
'roof_shape' => $roof_shape,
'number_of_rooms' => $number_of_rooms,
'number_of_stories' => $number_of_stories,
'contents' => $contents,
'liability_limits' => $liability_limits,
'medical_payments' => $medical_payments,
'residence_passed' => $residence_passed,
'insurance_claims' => $insurance_claims,
'type_of_loss' => $type_of_loss,
'paid_by_carrier' => $paid_by_carrier,
'date_of_occurance' => $date_of_occurance,
'have_any_pets' => $have_any_pets,
'gated_community' => $gated_community,
'burglar_alarm' => $burglar_alarm,
'roof_replaced' => $roof_replaced,
'roof_replaced_year' => $roof_replaced_year,
'built_over_sand' => $built_over_sand,
'built_over_water' => $built_over_water,
'roof_year' => $roof_year,
'electrical_year' => $electrical_year,
'plumbing_year' => $plumbing_year,
'heating_year' => $heating_year,
'sinkhole_activity' => $sinkhole_activity,
'swimming_pool' => $swimming_pool,
'swimming_pool_ground' => $swimming_pool_ground,
'swimming_pool_foundation' => $swimming_pool_foundation,
'house_frame' => $house_frame,
'primary_heating' => $primary_heating,
'hydrant_feet' => $hydrant_feet,
'fire_station' => $fire_station,
'flood_zone' => $flood_zone,
'cu_insured' => $cu_insured,
'namedInsured' => $namedInsured,
'gender' => $gender,
'maritalStatus' => $maritalStatus,
'educationLevel' => $educationLevel,
'occupation' => $occupation,
'ownRent' => $ownRent,
));
?>