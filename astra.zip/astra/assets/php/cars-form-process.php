<?php
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

define('WP_USE_THEMES', false);
require('../../../../../wp-blog-header.php');
if ( ! is_admin() ) {
    require_once( ABSPATH . 'wp-admin/includes/post.php' );
}
global $wpdb;
$table_name = $wpdb->prefix.'auto_forms_data';
// echo $table_name;
// Create table to store forms data
if (!function_exists('maybe_create_table')) {
    require_once ABSPATH . '/wp-admin/install-helper.php';
}

//check if table is not exist then create this table
if ($wpdb->get_var("SHOW TABLES LIKE '" . $table_name . "'") != $table_name) {
    $create_ddl = "CREATE TABLE $table_name (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, fname VARCHAR(255) NOT NULL, lname VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, phone VARCHAR(255) NOT NULL, adress VARCHAR(255) NOT NULL, DOB VARCHAR(255) NOT NULL, city VARCHAR(255) NOT NULL, state VARCHAR(255) NOT NULL, zip VARCHAR(255) NOT NULL, autoYear VARCHAR(255) NOT NULL, autoMake VARCHAR(255) NOT NULL, autoModal VARCHAR(255) NOT NULL, vinnumbr VARCHAR(255) NOT NULL, primaryVehicleUse VARCHAR(255) NOT NULL, commuteDistance VARCHAR(255) NOT NULL, work_sch VARCHAR(255) NOT NULL, ownLease VARCHAR(255) NOT NULL, makePay VARCHAR(255) NOT NULL, have_vehicle VARCHAR(255) NOT NULL, ride_share VARCHAR(255) NOT NULL, cu_insured VARCHAR(255) NOT NULL, namedInsured VARCHAR(255) NOT NULL, liability VARCHAR(255) NOT NULL, coverage VARCHAR(255) NOT NULL, gender VARCHAR(255) NOT NULL, maritalStatus VARCHAR(255) NOT NULL, educationLevel VARCHAR(255) NOT NULL, occupation VARCHAR(255) NOT NULL, ownRent VARCHAR(255) NOT NULL, licenseStatus VARCHAR(255) NOT NULL, sr_22_doc VARCHAR(255) NOT NULL, faultAccidents VARCHAR(255) NOT NULL, PIPAccident VARCHAR(255) NOT NULL, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
    $result = maybe_create_table($table_name, $create_ddl);
}
$errorMSG1 = '';
//first name
if (empty($_POST["fname"])) {
    $fname = '';
} else {
    $fname = stripslashes($_POST["fname"]);
}
//last name
if (empty($_POST["lname"])) {
    $lname = '';
} else {
    $lname = stripslashes($_POST["lname"]);
}
//adress
if (empty($_POST["adress"])) {
    $adress = '';
} else {
    $adress = stripslashes($_POST["adress"]);
}
//DOB
if (empty($_POST["DOB"])) {
    $DOB = '';
} else {
    $DOB = stripslashes($_POST["DOB"]);
}
//city
if (empty($_POST["city"])) {
    $city = '';
} else {
    $city = stripslashes($_POST["city"]);
}
//state
if (empty($_POST["state"])) {
    $state = '';
} else {
    $state = stripslashes($_POST["state"]);
}
//zip
if (empty($_POST["zip"])) {
    $zip = '';
} else {
    $zip = stripslashes($_POST["zip"]);
}
//Auto Year
if (empty($_POST["autoYear"])) {
    $autoYear = '';
} else {
    $autoYear = stripslashes($_POST["autoYear"]);
}
//Auto Make
if (empty($_POST["autoMake"])) {
    $autoMake = '';
} else {
    $autoMake = stripslashes($_POST["autoMake"]);
}
//Auto Modal
if (empty($_POST["autoModal"])) {
    $autoModal = '';
} else {
    $autoModal = stripslashes($_POST["autoModal"]);
}

//VIN Number
if (empty($_POST["vinnumbr"])) {
    $vinnumbr = '';
} else {
    $vinnumbr = stripslashes($_POST["vinnumbr"]);
}

//What is this car's primary use?
if (empty($_POST["primaryVehicleUse"])) {
    $primaryVehicleUse = '';
} else {
    $primaryVehicleUse = stripslashes($_POST["primaryVehicleUse"]);
}

//About how many miles each way?
if (empty($_POST["commuteDistance"])) {
    $commuteDistance = '';
} else {
    $commuteDistance = stripslashes($_POST["commuteDistance"]);
}

//Drive To Work Or School
if (empty($_POST["work_sch"])) {
    $work_sch = '';
} else {
    $work_sch = stripslashes($_POST["work_sch"]);
}

//Owned Or Lease
if (empty($_POST["ownLease"])) {
    $ownLease = '';
} else {
    $ownLease = stripslashes($_POST["ownLease"]);
}

//Do You Currently Make Payments On This Car?
if (empty($_POST["makePay"])) {
    $makePay = '';
} else {
    $makePay = stripslashes($_POST["makePay"]);
}

//How Long Have You Had This Vehicle?
if (empty($_POST["have_veh"])) {
    $have_veh = '';
} else {
    $have_veh = stripslashes($_POST["have_veh"]);
}

//Used for RideSharnig
if (empty($_POST["ride_shr"])) {
    $ride_shr = '';
} else {
    $ride_shr = stripslashes($_POST["ride_shr"]);
}

//Currently Insured?
if (empty($_POST["cu_insured"])) {
    $cu_insured = '';
} else {
    $cu_insured = stripslashes($_POST["cu_insured"]);
}

//Named of current insurer
if (empty($_POST["namedInsured"])) {
    $namedInsured = '';
} else {
    $namedInsured = stripslashes($_POST["namedInsured"]);
}

//YOUR CURRENT LIABILITY LIMITS
if (empty($_POST["liability"])) {
    $liability = '';
} else {
    $liability = stripslashes($_POST["liability"]);
}

//YOUR CURRENT COMPREHENSIVE / COLLISION
if (empty($_POST["coverage"])) {
    $coverage = '';
} else {
    $coverage = stripslashes($_POST["coverage"]);
}

//Gender
if (empty($_POST["gender"])) {
    $gender = '';
} else {
    $gender = stripslashes($_POST["gender"]);
}

//Marital Status
if (empty($_POST["maritalStatus"])) {
    $maritalStatus = '';
} else {
    $maritalStatus = stripslashes($_POST["maritalStatus"]);
}

//Education Level
if (empty($_POST["educationLevel"])) {
    $educationLevel = '';
} else {
    $educationLevel = stripslashes($_POST["educationLevel"]);
}

//Occupation
if (empty($_POST["occupation"])) {
    $occupation = '';
} else {
    $occupation = stripslashes($_POST["occupation"]);
}

//Own Or Rent House
if (empty($_POST["ownRent"])) {
    $ownRent = '';
} else {
    $ownRent = stripslashes($_POST["ownRent"]);
}

//License Status
if (empty($_POST["LicenseStatus"])) {
    $LicenseStatus = '';
} else {
    $LicenseStatus = stripslashes($_POST["LicenseStatus"]);
}

//Are you required to have an SR-22 or other Financial Responsibility document?
if (empty($_POST["SR_22_doc"])) {
    $SR_22_doc = '';
} else {
    $SR_22_doc = stripslashes($_POST["SR_22_doc"]);
}

//Any at –fault accidents in the last 3 years?
if (empty($_POST["faultAccidents"])) {
    $faultAccidents = '';
} else {
    $faultAccidents = stripslashes($_POST["faultAccidents"]);
}

//Have You had a PIP Accident in the last 5 Years?
if (empty($_POST["PIPAccident"])) {
    $PIPAccident = '';
} else {
    $PIPAccident = stripslashes($_POST["PIPAccident"]);
}

//EMAIL
if (empty($_POST["email"])) {
    $email = '';
} else {
    $email = stripslashes($_POST["email"]);
}
// MSG SUBJECT
if (empty($_POST["phone"])) {
    $phone = '';
} else {
    $phone = stripslashes($_POST["phone"]);
}

$EmailTo = 'shahwal.safdar@qwertyexperts.com';
$m_Source = "ContactForm";
$Subject = "New Message From My Conextion Cars Form ";
// prepare email body text
$Body = "";
$Body .= "First name: ";
$Body .= $fname;
$Body .= "\n";
$Body .= "Last name: ";
$Body .= $lname;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $email;
$Body .= "\n";
$Body .= "Phone: ";
$Body .= $phone;
$Body .= "\n";
$Body .= "Adress: ";
$Body .= $adress;
$Body .= "\n";
$Body .= "DOB: ";
$Body .= $DOB;
$Body .= "\n";
$Body .= "City: ";
$Body .= $city;
$Body .= "\n";
$Body .= "State: ";
$Body .= $state;
$Body .= "\n";
$Body .= "Zip Code: ";
$Body .= $zip;
$Body .= "\n";
$Body .= "Auto Year: ";
$Body .= $autoYear;
$Body .= "\n";
$Body .= "Auto Make: ";
$Body .= $autoMake;
$Body .= "\n";
$Body .= "Auto Modal: ";
$Body .= $autoModal;
$Body .= "\n";
$Body .= "VIN Number: ";
$Body .= $vinnumbr;
$Body .= "\n";
$Body .= "What is this car's primary use?: ";
$Body .= $primaryVehicleUse;
$Body .= "\n";
$Body .= "About how many miles each way?: ";
$Body .= $commuteDistance;
$Body .= "\n";
$Body .= "Drive To Work Or School: ";
$Body .= $work_sch;
$Body .= "\n";
$Body .= "Owned Or Lease: ";
$Body .= $ownLease;
$Body .= "\n";
$Body .= "Do You Currently Make Payments On This Car?: ";
$Body .= $makePay;
$Body .= "\n";
$Body .= "How Long Have You Had This Vehicle?: ";
$Body .= $have_veh;
$Body .= "\n";
$Body .= "Used for RideSharnig: ";
$Body .= $ride_shr;
$Body .= "\n";
$Body .= "Currently Insured?: ";
$Body .= $cu_insured;
$Body .= "\n";
$Body .= "Named of current insurer: ";
$Body .= $namedInsured;
$Body .= "\n";
$Body .= "Your Current liability Limits: ";
$Body .= $liability;
$Body .= "\n";
$Body .= "Your Current Comprehensive / Collision: ";
$Body .= $coverage;
$Body .= "\n";
$Body .= "Gender: ";
$Body .= $gender;
$Body .= "\n";
$Body .= "Marital Status: ";
$Body .= $maritalStatus;
$Body .= "\n";
$Body .= "Education Level: ";
$Body .= $educationLevel;
$Body .= "\n";
$Body .= "Occupation: ";
$Body .= $occupation;
$Body .= "\n";
$Body .= "Own Or Rent House: ";
$Body .= $ownRent;
$Body .= "\n";
$Body .= "License Status: ";
$Body .= $LicenseStatus;
$Body .= "\n";
$Body .= "Are you required to have an SR-22 or other Financial Responsibility document?: ";
$Body .= $SR_22_doc;
$Body .= "\n";
$Body .= "Any at –fault accidents in the last 3 years?: ";
$Body .= $faultAccidents;
$Body .= "\n";
$Body .= "Have You had a PIP Accident in the last 5 Years?: ";
$Body .= $PIPAccident;
$Body .= "\n";
$from = $email;
$headers = "From: " .($from) . "\r\n";
$headers .= "Reply-To: ".($from) . "\r\n";
$headers .= "Return-Path: ".($from) . "\r\n";;
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";
$headers .= "X-Priority: 3\r\n";
$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
$success = 0;
if ( mail($EmailTo,$Subject,$Body, $headers,"-f".$from."") ) {
    $success = 1;
    echo "success";
} else {
  $success = 0;
  echo "Something went wrong :(";
}


$wpdb->insert($table_name, array(
    'fname' => $fname,
    'lname' => $lname,
    'email' => $email,
    'phone' => $phone,
    'adress' => $adress,
    'DOB' => $DOB,
    'city' => $city,
    'state' => $state,
    'zip' => $zip,
    'autoYear' => $autoYear,
    'autoMake' => $autoMake,
    'autoModal' => $autoModal,
    'vinnumbr' => $vinnumbr,
    'primaryVehicleUse' => $primaryVehicleUse,
    'commuteDistance' => $commuteDistance,
    'work_sch' => $work_sch,
    'ownLease' => $ownLease,
    'makePay' => $makePay,
    'have_vehicle' => $have_veh,
    'ride_share' => $ride_shr,
    'cu_insured' => $cu_insured,
    'namedInsured' => $namedInsured,
    'liability' => $liability,
    'coverage' => $coverage,
    'gender' => $gender,
    'maritalStatus' => $maritalStatus,
    'educationLevel' => $educationLevel,
    'occupation' => $occupation,
    'ownRent' => $ownRent,
    'licenseStatus' => $LicenseStatus,
    'sr_22_doc' => $SR_22_doc,
    'faultAccidents' => $faultAccidents,
    'PIPAccident' => $PIPAccident,
));
?>