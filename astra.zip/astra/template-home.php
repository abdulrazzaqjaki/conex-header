<?php /* Template Name: Home Form */ ?>

<?php get_header(); ?>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style type="text/css">

.page-title{
    margin-top: 150px;
    text-align: center;
}
* {
    margin: 0;
    padding: 0
}

html {
    height: 100%
}
h1,h2,h3,h4,h5,h6{
    color: #054f93;
}
#heading {
    text-transform: uppercase;
    color: #054f93;
    font-weight: normal
}



#msform fieldset:not(:first-of-type) {
    display: none;
}

#msform input,
#msform textarea {
    padding: 8px 15px 8px 15px;
    border: 1px solid #054f93;
    border-radius: 6px;
    margin-bottom: 25px;
    margin-top: 2px;
    width: 100%;
    box-sizing: border-box;
    color: #2C3E50;
    background-color: transparent;
    font-size: 16px;
    letter-spacing: 1px
}

#msform input:focus,
#msform textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #054f93;
    outline-width: 0
}

#msform .action-button {
    width: 100px;
    background: #054f93;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 0px 10px 5px;
    float: right
}
#msform .action-button-previous {
    width: 100px;
    background: #054f93;
    color: #fff;
    border: 0 none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right;
}
.card {
    border: none;
}
.steps {
    font-size: 21px;
    color: #054f93;
    text-align: right
}
.fieldlabels {
    color: #054f93;
    text-align: left;
    display: block;
}
.progress {
    height: 8px
}
.select2-container{
    width: 100%!important;
    text-align: left;
}
.select2-container--default .select2-selection--single .select2-selection__arrow b{
    margin-top: 8px;
    
    border-color: #054f93 transparent transparent transparent;
}
.select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b{
    border-color: transparent transparent #054f93 transparent;
}

.select2-container--default .select2-selection--single{
    height: 41.12px;
    padding-top: 5px;
    border: 1px solid #054f93;
    margin-bottom: 25px;
    margin-top: 2px;
}
.select2-container--default .select2-search--dropdown .select2-search__field,
.select2-dropdown{
    border: 1px solid #054f93;
}
.select2-container--default .select2-results__option--highlighted[aria-selected]{
    background-color: #054f93;
}
.progress-bar {
    background-color: #054f93;
}

.fit-image {
    width: 100%;
    object-fit: cover
}
.form-card{
    text-align: left;
}
.primaryUse div input{
    -webkit-touch-callout: none;
    -webkit-tap-highlight-color: transparent;
    position: absolute;
    left: 0;
    top: 0;
    margin: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
    outline: 0;
}
.primaryUse div label{
    box-shadow: 0 2px 1px 0 rgb(0 0 0 / 6%);
    border-radius: 2.25em;
    transition: all .3s ease;
    margin: 0;
    border: 1px solid #054f93;
    display: block;
    text-align: center;
    background: #fff;
    color: #054f93;
    font-size: .8125em;
    border-radius: 1.0625rem;
    padding: 1em .5em;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}
.primaryUse div{
    display: inline-block;
    vertical-align: top;
    width: auto;
    min-width: 6.5em;
    margin: 0 .75em .75em 0;
    padding: 0;
    position: relative;
    min-width: 132px;
}
.primaryUse div:hover label {
    color: #054f93;
    border: 1px solid #054f93;
    box-shadow: none;
}
.is-primary_home label{
    min-height: 168px;
}
.primaryUse{
    text-align: left;
}
.primaryUse div label i {
    font-weight: 400;
    line-height: 1;
    pointer-events: none;
    display: block;
    margin-bottom: .2rem;
    font-size: 5.5em;
    width: 100%;
}
.primaryUse div.selected label {
    background: #054f93;
    color: #fff;
    border: 1px solid #054f93;
}
.commuteDistance div{
    min-width: 6.5em;
}
.have_veh div{
    min-width: 11.5em;
}
.primaryUse .fieldlabels{
    margin-bottom: 30px;
}
.commuteDistance .fieldlabels{
    margin:30px 0px;
}
.make_pay,#insured_named{
    display: none;
}
.primaryUse > div > label{
    padding: .5em !important;
}
.insurance_claims-yes, .roof_replaced-yes, .swimming_pool-ground, .current-insured-named{
    display: none;
}
.insurance_claims-yes.show, .roof_replaced-yes.show, .swimming_pool-ground.show{
    display: block;
}
#circleBar {
  text-align: center;
}
#circleBar .round {
  position: relative;
}
#circleBar canvas{
    transform: rotate(90deg);
}
#circleBar .round strong {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50% , -65%);
    font-size: 20px;
    color: #212121;
    font-weight: 400;
}
#circleBar span {
  display: block;
  color: #999;
  font-size: 16px;
  /*margin-top: 10px;*/
}
#circleBar span i {
  color: #ff5c5c;
  font-size: 22px;
  margin-right: 6px;
}
.err{
    display: none;
    margin: 0.5em 0 0;
    font-size: .85em;
    color: #bd003b;
}
#msform input[type='submit']{
    width: 100px;
    background: #054f93;
    color: #fff;
    border: 0 none;
    border-radius: 6px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right;
}
#msform .row{
    text-align: left;
}
.thankyou-call-us{
    background: #054f93;
    padding: 50px 0;
    display: none;
}
.thankyou-call-us-heading-title{
    color: #fff;
    text-align: center;
    margin-top: 50px;
}
.thankyou-call-us-divider-separator{
    display: block;
    width: 50px;
    height: 3px;
    background: rgba(255,255,255,.5);
    margin:20px auto;
}
.thankyou-call-us-text{
    color: #fff;
    font-size: 18px;
    text-align: center;
    font-family: "Work Sans", sans-serif;
    padding: 10px 0;
}
.thankyou-call-us-cta{
    text-decoration: none !important;
    padding: 13px 35px;
    background: #fff;
    color: #000;
    display: block;
    margin: 20px auto 50px;
    width: max-content;
    font-size: 16px;
    font-family: "Work Sans", sans-serif;
    text-transform: capitalize;
    border: 1px solid #fff;
}
.thankyou-call-us-cta:hover{
    background: transparent;
    color: #fff;
}
</style>
<div class="container-fluid">
	<div class="container">
		<div class="page-title">
			<!-- <h1><?php //the_title(); ?></h1> -->
		</div>
	</div>
</div>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 text-center p-0 mt-3 mb-2">
            <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                <form id="msform" method="post" action="/wp-content/themes/astra/assets/php/homes-form-process.php">
                    <div id="circleBar">
                        <div class="round" data-value="0.0" data-size="80" data-thickness="6"><strong>Start</strong></div>
                    </div>
                    <br> 
                    <!-- 1st step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 1 - 12</h2>
                                </div>
                            </div>
                            <div class="primaryUse">
                                <label class="fieldlabels" id="gender">Select the Style of Your Home</label>
                                <div class="home">
                                    <input type="radio" name="home" id="single-family-home" value="Single Family Home">
                                    <label for="single-family-home"><i class="fas fa-home"></i>Single Family Home</label>
                                </div>
                                <div class="home">
                                    <input type="radio" name="home" id="conde" value="Conde">
                                    <label for="conde"><i class="fas fa-building"></i>Conde</label>
                                </div>
                                <div class="home">
                                    <input type="radio" name="home" id="apartment" value="apartment">
                                    <label for="Apartment"><i class="fas fa-hotel"></i>Apartment</label>
                                </div>
                                <div class="home">
                                    <input type="radio" name="home" id="mobile-home" value="Mobile Home">
                                    <label for="mobile-home"><i class="fas fa-truck-moving"></i>Mobile Home</label>
                                </div>
                                <div class="home">
                                    <input type="radio" name="home" id="townhouse" value="Townhouse">
                                    <label for="townhouse"><i class="fas fa-city"></i>Townhouse</label>
                                </div>
                                <p>
                                   <span class="err" id="err-home">Required</span> 
                                </p>
                            </div>
                        </div> 
                        <input id="first_step" type="button" name="next" class="next action-button" value="Next" />
                    </fieldset>
                    <!-- 1st step end -->
                    <!-- 2nd step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 2 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <p id="car-info-txt">What is Your Address</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="fieldlabels">Property Address</label> 
                                <input id="p-adress" type="text" name="property_address" placeholder="Let's Start with your Property Address" />
                                <span class="err" id="err-p-adress">Required</span>   
                            </div>
                            <div class="col-md-6">
                              <label class="fieldlabels">Unit#</label> 
                                <input id="p-unit" type="text" name="unit" placeholder="unit" />
                                <span class="err" id="err-p-unit">Required</span>    
                            </div>
                        </div>
                        <input id="scnd_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 2nd step end -->
                    <!-- 3rd step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 3 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse">
                            <div class="row">
                                <div class="col-12">
                                    <p id="car-info-txt">Questions and answer:</p>
                                </div>
                            </div>
                            <label class="fieldlabels" id="primaryVehicleUse">Occupancy?</label>
                            <div class="commuting">
                                <input type="radio" name="occupancy" id="owner-and-occupant" value="Owner and Occupant">
                                <label for="owner-and-occupant"><i class="fal fa-home-heart"></i>Owner and <br> Occupant</label>
                            </div>
                            <div class="personal">
                                <input type="radio" name="occupancy" id="tenant" value="Tenant (12 months lease)">
                                <label for="tenant"><i class="fas fa-key"></i>Tenant <br> (12 months lease)</label>
                            </div>
                            <div class="business">
                                <input type="radio" name="occupancy" id="landlord" value="Landlord (12 months lease)">
                                <label for="landlord" ><i class="fas fa-hands"></i>Landlord <br> (12 months lease)</label>
                            </div>
                            <p>
                               <span class="err" id="err-occupancy">Required</span> 
                            </p>
                        </div> 
                        <div class="primaryUse">
                            <label class="fieldlabels" id="commuteDistance">Is this your primary home?</label>
                            <div class="is-primary_home">
                                <input type="radio" id="primary_home" name="primary_home" value="Yes, I occupy this home the majority of the years">
                                <label for="primary_home" ><i class="fas fa-undo"></i> Yes, I occupy this<br> home the majority<br> of the years</label>
                            </div>
                            <div class="is-primary_home">
                                <input type="radio" id="secondary-home" name="primary_home" value="No, this is my secondary home">
                                <label for="secondary-home"><i class="fas fa-sync"></i> No, this is my<br> secondary home</label>
                            </div>
                            <p>
                               <span class="err" id="err-primary_home">Required</span> 
                            </p>
                        </div>
                        <input id="thrd_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 3rd step end -->
                    <!-- 4th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 4 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="form-card">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="fieldlabels">Use of the property: </label> 
                                    <select id="use_of_the_property" name="use_of_the_property" class="single js-states form-control">
                                        <option value="">Property Use</option>
                                        <option value="Primary Residence">Primary Residence</option>
                                        <option value="Secondary or Seasonal Home">Secondary or Seasonal Home</option>
                                        <option value="Investment Property">Investment Property</option>
                                    </select>
                                    <span class="err" id="err-use_of_the_property">Required</span> 
                                </div>
                                <div class="col-md-6">
                                    <div class="moreinfo-about-home">
                                        <label class="fieldlabels" for="year_built">Year Built</label>
                                        <input type="text" name="year_built" id="year_built" placeholder="Year Built">
                                        <span class="err" id="err-year_built">Required</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="moreinfo-about-home">
                                        <label class="fieldlabels" for="square_feet">Square Feet</label>
                                        <select id="square_feet" name="square_feet" class="single js-states form-control">
                                            <option value="">Square Feet</option>
                                            <option value="1,000 or Less">1,000 or Less</option>
                                            <option value="1,000 to 2,000">1,000 to 2,000</option>
                                            <option value="2,000 to 3,000">2,000 to 3,000</option>
                                            <option value="3,000 to 4,000">3,000 to 4,000</option>
                                            <option value="4,000 to 5,000">4,000 to 5,000</option>
                                            <option value="5,000 +">5,000+ </option>
                                        </select>
                                        <span class="err" id="err-square_feet">Required</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="moreinfo-about-home">
                                        <label class="fieldlabels" for="construction_type">Construction Type</label>
                                        <select id="construction_type" name="construction_type" class="single js-states form-control">
                                            <option value="">Construction Type</option>
                                            <option value="Brick">Brick</option>
                                            <option value="Brick Veneer">Brick Veneer</option>
                                            <option value="Stucco">Stucco</option>
                                            <option value="Fire Resistant">Fire Resistant</option>
                                            <option value="Semi Wind-Resistive">Semi Wind-Resistive</option>
                                            <option value="Wind-Resistive">Wind-Resistive</option>
                                            <option value="Superior">Superior</option>
                                        </select>
                                        <span class="err" id="err-construction_type">Required</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="moreinfo-about-home">
                                        <label class="fieldlabels" for="roof_type">Roof Type</label>
                                        <select id="roof_type" name="roof_type" class="single js-states form-control">
                                            <option value="">Roof Type</option>
                                            <option value="Aluminum">Aluminum</option>
                                            <option value="Asbestos">Asbestos</option>
                                            <option value="Asphalt">Asphalt</option>
                                            <option value="Cedars Shake">Cedars Shake</option>
                                            <option value="Cedars Shingles">Cedars Shingles</option>
                                            <option value="Clay Tile">Clay Tile</option>
                                            <option value="Composite Shingles">Composite Shingles</option>
                                            <option value="Concrete">Concrete</option>
                                            <option value="Concrete Tile">Concrete Tile</option>
                                            <option value="Copper">Copper</option>
                                            <option value="Fibber Glass">Fibber Glass</option>
                                            <option value="Gravel">Gravel</option>
                                            <option value="Metal">Metal</option>
                                            <option value="Plastic">Plastic</option>
                                            <option value="Plywood">Plywood</option>
                                            <option value="Recycled">Recycled</option>
                                            <option value="Reinforced Concrete">Reinforced Concrete</option>
                                            <option value="Rock">Rock</option>
                                            <option value="Roll Roofing">Roll Roofing</option>
                                            <option value="Rubber">Rubber</option>
                                            <option value="Single Ply Membrane System">Single Ply Membrane System</option>
                                            <option value="Slate">Slate</option>
                                            <option value="Spanish Tile">Spanish Tile</option>
                                            <option value="Steel">Steel</option>
                                            <option value="Steel / Porcelain Shingles">Steel / Porcelain Shingles</option>
                                            <option value="Tar and Gravel">Tar and Gravel</option>
                                            <option value="Tin">Tin</option>
                                            <option value="Wood Shake">Wood Shake</option>
                                            <option value="Wood Shingle">Wood Shingle</option>
                                            <option value="Other">Other</option>
                                        </select>
                                        <span class="err" id="err-roof_type">Required</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="moreinfo-about-home">
                                        <label class="fieldlabels" for="roof_shape">Roof Shape</label>
                                        <select id="roof_shape" name="roof_shape" class="single js-states form-control">
                                            <option value="">Roof Shape</option>
                                            <option value="Gable">Gable</option>
                                            <option value="Hip">Hip</option>
                                            <option value="Gambrel">Gambrel</option>
                                            <option value="Mansard">Mansard</option>
                                            <option value="Complex / Custom">Complex / Custom</option>
                                            <option value="Flat">Flat</option>
                                            <option value="Shed">Shed</option>
                                        </select> 
                                        <span class="err" id="err-roof_shape">Required</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <input id="forth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 4th step end -->
                    <!-- 5th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 5 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="fieldlabels" for="number_of_rooms">How many rooms?</label> 
                                <input type="text" name="number_of_rooms" id="number_of_rooms" placeholder="Number Of Rooms">
                                <span class="err" id="err-number_of_rooms">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Number of stories:</label> 
                                <select id="number_of_stories" name="number_of_stories" class="single js-states form-control">
                                    <option value="">Number of stories</option>
                                    <option value="1 Story">1 Story</option>
                                    <option value="1-1/2 Stories">1-1/2 Stories</option>
                                    <option value="2 Stories">2 Stories</option>
                                    <option value="2-1/2 Stories">2-1/2 Stories</option>
                                    <option value="3 Stories">3 Stories</option>
                                    <option value="4 Stories">4 Stories</option>
                                </select>
                                <span class="err" id="err-number_of_stories">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Contents:</label> 
                                <select id="contents" name="contents" class="single js-states form-control">
                                    <option value="">Contents</option>
                                    <option value="$10,000 or Less">$10,000 or Less</option>
                                    <option value="$15,000">$15,000</option>
                                    <option value="$20,000">$20,000</option>
                                    <option value="$25,000">$25,000</option>
                                    <option value="$30,000">$30,000</option>
                                    <option value="$35,000">$35,000</option>
                                    <option value="$40,000">$40,000</option>
                                    <option value="$45,000">$45,000</option>
                                    <option value="$50,000">$50,000</option>
                                    <option value="$60,000">$60,000</option>
                                    <option value="$70,000">$70,000</option>
                                    <option value="$80,000">$80,000</option>
                                    <option value="$90,000">$90,000</option>
                                    <option value="$100,000">$100,000</option>
                                    <option value="$125,000">$125,000</option>
                                    <option value="$150,000">$150,000</option>
                                    <option value="$175,000">$175,000</option>
                                    <option value="$200,000">$200,000+</option>
                                </select>
                                <span class="err" id="err-contents">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Liability limits:</label> 
                                <select id="liability_limits" name="liability_limits" class="single js-states form-control">
                                    <option value="">Liability limits</option>
                                    <option value="$100,000">$100,000</option>
                                    <option value="$300,000">$300,000</option>
                                    <option value="$500,000">$500,000</option>
                                    <option value="$1,000,000">$1,000,000</option>
                                </select>
                                <span class="err" id="err-liability_limits">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Medical payments:</label> 
                                <select id="medical_payments" name="medical_payments" class="single js-states form-control">
                                    <option value="">Medical payments</option>
                                    <option value="$1,000">$1,000</option>
                                    <option value="$2,000">$2,000</option>
                                    <option value="$5,000">$5,000</option>
                                </select>
                                <span class="err" id="err-medical_payments">Required</span>
                            </div>
                        </div>
                        <input id="fifth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 5th step end -->
                    <!-- 6th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 6 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse">
                            <label class="fieldlabels" id="gender">Any residence of the house has passed or has of the following:</label>
                            <div class="residence-of-house-passed">
                                <input type="radio" name="residence_passed" id="bankruptcy" value="Bankruptcy">
                                <label for="bankruptcy"><i class="fas fa-home"></i>Bankruptcy</label>
                            </div>
                            <div class="residence-of-house-passed">
                                <input type="radio" name="residence_passed" id="foreclosure" value="Foreclosure">
                                <label for="foreclosure"><i class="fas fa-home"></i>Foreclosure</label>
                            </div>
                            <div class="residence-of-house-passed">
                                <input type="radio" name="residence_passed" id="felony" value="Felony">
                                <label for="felony"><i class="fas fa-home"></i>Felony</label>
                            </div>
                            <div class="residence-of-house-passed">
                                <input type="radio" name="residence_passed" id="first-party-law-suit" value="First Party law Suit">
                                <label for="first-party-law-suit"><i class="fas fa-home"></i>First Party law Suit</label>
                            </div>
                            <p>
                                <span class="err" id="err-residence_passed">Required</span>
                            </p>
                        </div>
                        <div class="primaryUse commuteDistance insurance_claims">
                            <label class="fieldlabels" id="insurance_claims">Insurance claims?</label>
                            <div>
                                <input type="radio" id="insurance_claims_0" name="insurance_claims" value="Yes">
                                <label for="insurance_claims_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="insurance_claims_1" name="insurance_claims" value="No">
                                <label for="insurance_claims_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-insurance_claims">Required</span>
                            </p>
                        </div>
                        <div class="form-card insurance_claims-yes">
                            <div>
                                <label class="fieldlabels" for="type_of_loss">Description</label>
                                <input type="text" id="type_of_loss" name="type_of_loss" placeholder="Type Of Loss">
                                <span class="err" id="err-type_of_loss">Required</span>
                            </div>
                            <div>
                                <label class="fieldlabels" for="paid_by_carrier">Amount Paid by Carrier</label>
                                <input type="text" id="paid_by_carrier" name="paid_by_carrier" placeholder="$">
                                <span class="err" id="err-paid_by_carrier">Required</span> 
                            </div>
                            <div>
                                <label class="fieldlabels" for="date_of_occurance">Date Of Occurance</label>
                                <input type="date" id="date_of_occurance" name="date_of_occurance">
                                <span class="err" id="err-date_of_occurance">Required</span>  
                            </div>
                        </div>
                        <input id="sixth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 6th step end -->
                    <!-- 7th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 7 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <label class="fieldlabels">Do you have any pets?</label> 
                                <select id="have_any_pets" name="have_any_pets" class="single js-states form-control">
                                    <option value="">Have any pets</option>
                                    <option value="None">None</option>
                                    <option value="Dog - Akita">Dog - Akita</option>
                                    <option value="Dog - Alaskan Malamute">Dog - Alaskan Malamute</option>
                                    <option value="Dog - American Bull Terrier">Dog - American Bull Terrier</option>
                                    <option value="Dog - American Staffordshire Terrier">Dog - American Staffordshire Terrier</option>
                                    <option value="Dog - Bull Mastiff">Dog - Bull Mastiff</option>
                                    <option value="Dog - Chow">Dog - Chow</option>
                                    <option value="Dog - Dingo">Dog - Dingo</option>
                                    <option value="Dog - Doberman">Dog - Doberman</option>
                                    <option value="Dog - Jerman Shephard">Dog - Jerman Shephard</option>
                                    <option value="Dog - Husky">Dog - Husky</option>
                                    <option value="Dog - Pit Bull">Dog - Pit Bull</option>
                                    <option value="Dog - Pit Bull Terrier">Dog - Pit Bull Terrier</option>
                                    <option value="Dog - Presa Canario">Dog - Presa Canario</option>
                                    <option value="Dog - Mix">Dog - Mix</option>
                                    <option value="Dog - Rottweiler">Dog - Rottweiler</option>
                                    <option value="Dog - Staffordshire Bull Terrier">Dog - Staffordshire Bull Terrier</option>
                                    <option value="Dog - Wolf Hybrid">Dog - Wolf Hybrid</option>
                                    <option value="Dog - Other Breed">Dog - Other Breed</option>
                                    <option value="Livestock - Cow">Livestock - Cow</option>
                                </select>
                                <span class="err" id="err-have_any_pets">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Gated Community:</label> 
                                <select id="gated_community" name="gated_community" class="single js-states form-control">
                                    <option value="">Gated Community</option>
                                    <option value="Not Gated">Not Gated</option>
                                    <option value="Single Entry Gated">Single Entry Gated</option>
                                    <option value="24-Hour Security Patrol">24-Hour Security Patrol</option>
                                    <option value="24-Hour Manned Gates">24-Hour Manned Gates</option>
                                    <option value="Pass-Key Gates">Pass-Key Gates</option>
                                </select>
                                <span class="err" id="err-gated_community">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Burglar Alarm:</label> 
                                <select id="burglar_alarm" name="burglar_alarm" class="single js-states form-control">
                                    <option value="">Burglar Alarm</option>
                                    <option value="None">None</option>
                                    <option value="Monitored">Monitored</option>
                                    <option value="Unmonitored">Unmonitored</option>
                                </select>
                                <span class="err" id="err-burglar_alarm">Required</span>
                            </div>
                        </div>
                        <input id="sevth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 7th step end -->
                    <!-- 8th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 8 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="primaryUse commuteDistance roof_replaced">
                            <label class="fieldlabels" id="roof_replaced">Has your roof been replaced?</label>
                            <div>
                                <input type="radio" id="roof_replaced_0" name="roof_replaced" value="Yes">
                                <label for="roof_replaced_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="roof_replaced_1" name="roof_replaced" value="No">
                                <label for="roof_replaced_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-roof_replaced">Required</span>
                            </p>
                        </div>
                        <div class="form-card roof_replaced-yes">
                            <div>
                                <label class="fieldlabels" for="roof_replaced_year">What Year?</label>
                                <input type="text" name="roof_replaced_year" id="roof_replaced_year" placeholder="What Year?">
                                <span class="err" id="err-roof_replaced_year">Required</span>
                            </div>
                            <div class="built_over_sand primaryUse">
                                <label class="fieldlabels">Built over sand?</label>
                                <div>
                                    <input type="radio" id="built_over_sand_0" name="built_over_sand" value="Yes">
                                    <label for="built_over_sand_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="built_over_sand_1" name="built_over_sand" value="No">
                                    <label for="built_over_sand_1">NO</label>
                                </div>
                                <p>
                                    <span class="err" id="err-built_over_sand">Required</span>
                                </p>
                            </div>
                            <div class="built_over_water primaryUse">
                                <label class="fieldlabels">Built over water?</label>
                                <div>
                                    <input type="radio" id="built_over_water_0" name="built_over_water" value="Yes">
                                    <label for="built_over_water_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="built_over_water_1" name="built_over_water" value="No">
                                    <label for="built_over_water_1">NO</label>
                                </div>
                                <p>
                                    <span class="err" id="err-built_over_water">Required</span>
                                </p>
                            </div>
                            <label class="fieldlabels my-4"><b>In what year were these systems repaired:</b></label>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="fieldlabels" for="roof_year">Roof</label>
                                    <input type="text" name="roof_year" id="roof_year" placeholder="Roof Year">
                                    <span class="err" id="err-roof_year">Required</span>
                                </div>
                                <div class="col-md-6">
                                    <label class="fieldlabels" for="electrical_year">Electrical</label>
                                    <input type="text" name="electrical_year" id="electrical_year" placeholder="Electrical Year">
                                    <span class="err" id="err-electrical_year">Required</span>
                                </div>
                                <div class="col-md-6">
                                    <label class="fieldlabels" for="plumbing_year">Plumbing</label>
                                    <input type="text" name="plumbing_year" id="plumbing_year" placeholder="Plumbing Year">
                                    <span class="err" id="err-plumbing_year">Required</span>
                                </div>
                                <div class="col-md-6">
                                    <label class="fieldlabels" for="heating_year">Heating</label>
                                    <input type="text" name="heating_year" id="heating_year" placeholder="Heating Year">
                                    <span class="err" id="err-heating_year">Required</span>
                                </div>
                            </div>
                        </div>
                        <input id="eight_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 8th step end -->
                    <!-- 9th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 9 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="built_over_water primaryUse">
                            <label class="fieldlabels">Sinkhole activity?</label>
                            <div>
                                <input type="radio" id="sinkhole_activity_0" name="sinkhole_activity" value="Yes">
                                <label for="sinkhole_activity_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="sinkhole_activity_1" name="sinkhole_activity" value="No">
                                <label for="sinkhole_activity_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-sinkhole_activity">Required</span>
                            </p>
                        </div>
                        <div class="swimming_pool primaryUse">
                            <label class="fieldlabels">Swimming Pool?</label>
                            <div>
                                <input type="radio" id="swimming_pool_0" name="swimming_pool" value="Yes">
                                <label for="swimming_pool_0">YES</label>
                            </div>
                            <div>
                                <input type="radio" id="swimming_pool_1" name="swimming_pool" value="No">
                                <label for="swimming_pool_1">NO</label>
                            </div>
                            <p>
                                <span class="err" id="err-swimming_pool">Required</span>
                            </p>
                        </div>
                        <div class="swimming_pool-ground">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="fieldlabels">Swimming Pool Ground?</label> 
                                    <select id="swimming_pool_ground" name="swimming_pool_ground" class="single js-states form-control">
                                        <option value="">Select Option</option>
                                        <option value="Above Ground">Above Ground</option>
                                        <option value="In Ground">In Ground</option>
                                    </select>
                                    <span class="err" id="err-swimming_pool_ground">Required</span>
                                </div>
                                <div class="col-md-6">
                                    <label class="fieldlabels">What type of foundation?</label> 
                                    <select id="swimming_pool_foundation" name="swimming_pool_foundation" class="single js-states form-control">
                                        <option value="">Select Option</option>
                                        <option value="Slab">Slab</option>
                                        <option value="Crawl Space">Crawl Space</option>
                                        <option value="Basement">Basement</option>
                                        <option value="Pier and Beam / Pilling">Pier and Beam / Pilling</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <span class="err" id="err-swimming_pool_foundation">Required</span>
                                </div>
                            </div>
                        </div>
                        <input id="ninth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 9th step end -->
                    <!-- 10th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 10 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="fieldlabels">Frame of the house?</label> 
                                <select id="house_frame" name="house_frame" class="single js-states form-control">
                                    <option value="">Select Option</option>
                                    <option value="Wood Frame">Wood Frame</option>
                                    <option value="Masonary">Masonary</option>
                                    <option value="Concrete">Concrete</option>
                                    <option value="Log">Log</option>
                                    <option value="Other">Other</option>
                                </select>
                                <span class="err" id="err-house_frame">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Home’s primary heating?</label> 
                                <select id="primary_heating" name="primary_heating" class="single js-states form-control">
                                     <option value="">Select Option</option>
                                    <option value="Forced Air (Central)">Forced Air (Central)</option>
                                    <option value="Electric">Electric</option>
                                    <option value="Boiler">Boiler</option>
                                    <option value="Wood Stove">Wood Stove</option>
                                    <option value="No Central Heat Source">No Central Heat Source</option>
                                    <option value="Other">Other</option>
                                </select>
                                <span class="err" id="err-primary_heating">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Hydrant within 1,000 feet?</label> 
                                <select id="hydrant_feet" name="hydrant_feet" class="single js-states form-control">
                                    <option value="">Select Option</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                    <option value="Don't Know">Don't Know</option>
                                </select>
                                <span class="err" id="err-hydrant_feet">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Nearest fire station?</label> 
                                <select id="fire_station" name="fire_station" class="single js-states form-control">
                                    <option value="">Select Option</option>
                                    <option value="1-5 Miles">1-5 Miles</option>
                                    <option value="5-10 Miles">5-10 Miles</option>
                                    <option value="10+ Miles">10+ Miles</option>
                                </select>
                                <span class="err" id="err-fire_station">Required</span>
                            </div>
                            <div class="col-12 primaryUse">
                                <label class="fieldlabels">Flood Zone</label>
                                <div>
                                    <input type="radio" id="flood_zone_0" name="flood_zone" value="Yes">
                                    <label for="flood_zone_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="flood_zone_1" name="flood_zone" value="No">
                                    <label for="flood_zone_1">NO</label>
                                </div>
                                <p>
                                    <span class="err" id="err-flood_zone">Required</span>
                                </p>
                            </div>
                            <div class="col-12 cu_insured primaryUse">
                                <label class="fieldlabels">Currently Insured?</label>
                                <div>
                                    <input type="radio" id="cu_insured_0" name="cu_insured" value="Yes">
                                    <label for="cu_insured_0">YES</label>
                                </div>
                                <div>
                                    <input type="radio" id="cu_insured_1" name="cu_insured" value="No">
                                    <label for="cu_insured_1">NO</label>
                                </div>
                                <p>
                                    <span class="err" id="err-cu_insured">Required</span>
                                </p>
                            </div>
                        </div>
                        <div class="current-insured-named"> 
                            <div class="row ">
                                <div class="col-12">
                                    <label class="fieldlabels">Named of current insurer</label> 
                                    <select id="namedInsured" name="namedInsured" class="single js-states form-control">
                                        <option value="">Select Option</option>
                                        <option value="21st centtury Insurance">21st centtury Insurance</option>
                                        <option value="AAA Insurance Co.">AAA Insurance Co.</option>
                                        <option value="Allstate">Allstate</option>
                                        <option value="American Family">American Family</option>
                                        <option value="AMICA">AMICA</option>
                                        <option value="Country Financial">Country Financial</option>
                                        <option value="Esurance">Esurance</option>
                                        <option value="Farmers">Farmers</option>
                                        <option value="Geico">Geico</option>
                                        <option value="Liberty Mutual">Liberty Mutual</option>
                                        <option value="Mercury">Mercury</option>
                                        <option value="Metlife">Metlife</option>
                                        <option value="Nationwide">Nationwide</option>
                                        <option value="Progressive">Progressive</option>
                                        <option value="Safeco">Safeco</option>
                                        <option value="State Farm">State Farm</option>
                                        <option value="The Hartford">The Hartford</option>
                                        <option value="Travelers">Travelers</option>
                                        <option value="USAA">USAA</option>
                                        <option value="Other">Other</option>
                                    </select>
                                    <span class="err" id="err-namedInsured">Required</span> 
                                </div>
                            </div>
                        </div>
                        <input id="tenth_step" type="button" name="next" class="next action-button" value="Next" /> 
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 10th step end -->
                    <!-- 11th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 11 - 12</h2>
                                </div>
                            </div>
                        </div>
                        <label class="fieldlabels">Let's Find Some Discounts</label>
                        <div class="primaryUse">
                            <label class="fieldlabels" id="gender">Gender</label>
                            <div class="male">
                                <input type="radio" name="gender" id="gender_0" value="Male">
                                <label for="gender_0"><i class="fas fa-male"></i>Male</label>
                            </div>
                            <div class="female">
                                <input type="radio" name="gender" id="gender_1" value="Female">
                                <label for="gender_1"><i class="fas fa-female"></i>Female</label>
                            </div>
                            <p>
                               <span class="err" id="err-gender">Required</span> 
                            </p>
                        </div>
                        <div class="primaryUse have_veh">
                            <label id="maritalStatus" class="fieldlabels">Marital Status</label>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_0" value="Single">
                                <label class="ng-tns-c3-147" for="maritalStatus_0">Single (never married)</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_1" value="Married">
                                <label class="ng-tns-c3-147" for="maritalStatus_1">Married</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_2" value="Divorced">
                                <label class="ng-tns-c3-147" for="maritalStatus_2">Divorced</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_3" value="Widowed"> 
                                <label class="ng-tns-c3-147" for="maritalStatus_3">Widowed</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_4" value="Civil Union">
                                <label class="ng-tns-c3-147" for="maritalStatus_4">Civil Union</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_5" value="Separated">
                                <label class="ng-tns-c3-147" for="maritalStatus_5">Separated</label>
                            </div>
                            <div>
                                <input type="radio" name="maritalStatus" id="maritalStatus_6" value="Domestic Partner">
                                <label class="ng-tns-c3-147" for="maritalStatus_6">Domestic Partner</label>
                            </div>
                            <p>
                                <span class="err" id="err-maritalStatus">Required</span>
                            </p>
                        </div>
                        <div class="row ">
                            <div class="col-md-6">
                                <label class="fieldlabels">Education Level</label> 
                                <select id="educationLevel" name="educationLevel" class="single js-states form-control">
                                    <option value="">Select Option</option>
                                    <option value="No High school Diploma or GED">No High school Diploma or GED</option>
                                    <option value="High school Diploma or GED">High school Diploma or GED</option>
                                    <option value="Vacation / Technical Degree">Vacation / Technical Degree</option>
                                    <option value="Completed some college, No degree">Completed some college, No degree</option>
                                    <option value="Bachelors Degree">Bachelors Degree</option>
                                    <option value="Masters Degree">Masters Degree</option>
                                    <option value="PHD / Doctorate">PHD / Doctorate</option>
                                    <option value="Medical Degree">Medical Degree</option>
                                    <option value="Law Degree">Law Degree</option>
                                    <option value="Associates Degree">Associates Degree</option>
                                </select>
                                <span class="err" id="err-educationLevel">Required</span>
                            </div>
                            <div class="col-md-6">
                                <label class="fieldlabels">Occupation:</label> 
                                <select id="occupation" name="occupation" class="single js-states form-control">
                                    <option value="">Select Option</option>
                                    <option value="Homemaker (Full-time)">Homemaker (Full-time)</option>
                                    <option value="Retired (Full-time)">Retired (Full-time)</option>
                                    <option value="Unemployed">Unemployed</option>
                                    <option value="Student (Full-time)">Student (Full-time)</option>
                                    <option value="Agriculture / Forestory / Fishing">Agriculture / Forestory / Fishing</option>
                                    <option value="Engineer / Architect Science / Math">Engineer / Architect Science / Math</option>
                                    <option value="Food Service / Hotel Services">Food Service / Hotel Services</option>
                                    <option value="Government / Military">Government / Military</option>
                                    <option value="Information Technology">Information Technology</option>
                                    <option value="Insurance">Insurance</option>
                                    <option value="Legal / Law Enforcement / Security">Legal / Law Enforcement / Security</option>
                                    <option value="Medical / Social Servicse / Religion">Medical / Social Servicse / Religion</option>
                                    <option value="Personal Care/Service">Personal Care/Service</option>
                                    <option value="Production / Manufacturing">Production / Manufacturing</option>
                                    <option value="Repair / Maintenance / Grounds">Repair / Maintenance / Grounds</option>
                                    <option value="Sports / Recreation">Sports / Recreation</option>
                                    <option value="Travel / Transportation / Storage">Travel / Transportation / Storage</option>
                                    <option value="Art / Design / Media">Art / Design / Media</option>
                                    <option value="Banking / Financial / Real Estate">Banking / Financial / Real Estate</option>
                                    <option value="Bussiness / Sales/ Office">Bussiness / Sales/ Office</option>
                                    <option value="Construction / Energy / Mining">Construction / Energy / Mining</option>
                                    <option value="Education / Library">Education / Library</option>
                                </select>
                                <span class="err" id="err-occupation">Required</span>
                            </div>
                            <div class="col-md-6">
                                <div class="primaryUse">
                                    <label class="fieldlabels">Own or rent house</label>
                                    <div>
                                        <input type="radio" id="ownRent_0" name="ownRent" value="Own">
                                        <label for="ownRent_0">Own</label>
                                    </div>
                                    <div>
                                        <input type="radio" id="ownRent_1" name="ownRent" value="Rent">
                                        <label for="ownRent_1">Rent</label>
                                    </div>
                                    <p>
                                        <span class="err" id="err-ownRent">Required</span>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="primaryUse">
                                    <label class="fieldlabels">License Status</label>
                                    <select id="LicenseStatus" name="LicenseStatus" class="single js-states form-control">
                                        <option value="">Select Option</option>
                                        <option value="Valid">Valid</option>
                                        <option value="Suspended">Suspended</option>
                                        <option value="Revoked">Revoked</option>
                                        <option value="Expired">Expired</option>
                                    </select>
                                    <span class="err" id="err-LicenseStatus">Required</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="primaryUse">
                                    <label class="fieldlabels">Suspended</label>
                                    <div>
                                        <input type="radio" id="suspended_0" name="suspended" value="Yes">
                                        <label for="suspended_0">Yes</label>
                                    </div>
                                    <div>
                                        <input type="radio" id="suspended_1" name="suspended" value="No">
                                        <label for="suspended_1">No</label>
                                    </div>
                                    <p>
                                        <span class="err" id="err-suspended">Required</span>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="primaryUse">
                                    <label class="fieldlabels">Fault Accidents</label>
                                    <div>
                                        <input type="radio" id="faultAccidents_0" name="faultAccidents" value="Yes">
                                        <label for="faultAccidents_0">Yes</label>
                                    </div>
                                    <div>
                                        <input type="radio" id="faultAccidents_1" name="faultAccidents" value="No">
                                        <label for="faultAccidents_1">No</label>
                                    </div>
                                    <p>
                                        <span class="err" id="err-faultAccidents">Required</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <input id="elvnth_step" type="button" name="next" class="next action-button" value="Next" />  
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 11th step end -->
                    <!-- 12th step start -->
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="steps">Step 12 - 12</h2>
                                </div>
                            </div>
                            <div>
                                <label class="fieldlabels">First Name</label> 
                                <input id="fname" type="text" name="fname" placeholder="First Name" />
                                <span class="err" id="err-fname">Required</span>   
                            </div>
                            <div>
                               <label class="fieldlabels">Last Name</label> 
                                <input id="lname" type="text" name="lname" placeholder="Last Name" />
                                <span class="err" id="err-lname">Required</span>  
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">Email</label> 
                                    <input id="email" type="email" name="email" placeholder="Enter Your email" />
                                    <span class="err" id="err-email">Required</span> 
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">Phone</label> 
                                    <input id="tel" type="tel" name="phone" placeholder="Enter Your contact number" />
                                    <span class="err" id="err-tel">Required</span> 
                                </div>
                            </div>
                            <div>
                                <label class="fieldlabels">DOB</label> 
                                <input id="dob" type="date" name="DOB" placeholder="mm/dd/yy" />
                                <span class="err" id="err-dob">Required</span>
                            </div>
                            <div>
                                <label class="fieldlabels">Adress</label> 
                                <input id="adress" type="adress" name="adress" placeholder="Enter Your Adress" />
                                <span class="err" id="err-adress">Required</span>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">City</label> 
                                    <input id="city" type="text" name="city" placeholder="Enter Your city" /> 
                                    <span class="err" id="err-city">Required</span>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <label class="fieldlabels">State</label> 
                                    <input id="state" type="text" name="state" placeholder="Enter Your state" />
                                    <span class="err" id="err-state">Required</span> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <label class="fieldlabels">Zip</label> 
                                    <input id="zip" type="text" name="zip" placeholder="Enter Zip Code" />
                                    <span class="err" id="err-zip">Required</span>
                                </div>
                            </div>
                        </div> 
                        <input id="btnsubmit" type="submit" name="submit" value="Submit" class="next action-button"/>
                        <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <!-- 12th step end -->
                    <!-- thankyou step -->
                    <fieldset class="thankyou-fieldset">
                        <div>
                            <h1>Thank You</h1>
                            <div id="msgSubmit"></div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<div class="thankyou-call-us">
    <div class="ast-container">
        <div class="row">
            <div class="col-md-6">
                <h3 class="thankyou-call-us-heading-title">Call US</h3>
                <span class="thankyou-call-us-divider-separator"></span>
                <p class="thankyou-call-us-text">Feel free to give us a call directly to be a connected with a covered advisor</p>
                <a href="tel:+923334415875" class="thankyou-call-us-cta" role="button">Call Now</span></a>
            </div>
            <div class="col-md-6">
                <h3 class="thankyou-call-us-heading-title">SCHEDULE A CALL</h3>
                <span class="thankyou-call-us-divider-separator"></span>
                <p class="thankyou-call-us-text">If you are busy, schedule a call below and a covered advisor will call you</p>
                <a href="https://calendly.com/willmorefrancis" target="_blank" class="thankyou-call-us-cta" role="button">Schedule a Call</span></a>
            </div>
        </div>
    </div>
</div>
<div class="ast-container">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.0/circle-progress.min.js'></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.err').hide();
    var errStatus;
    // validation for 1st step
    $('#first_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if($("input[name='home']:checked").val()) {} else {
           errStatus = 1;
           $('#err-home').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //2nd step validation
    $('#scnd_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#p-adress").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-p-adress').show();
        }
        if( jQuery("#p-unit").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-p-unit').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //3rd step validation
    $('#thrd_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if($("input[name='occupancy']:checked").val()) {} else {
           errStatus = 1;
           $('#err-occupancy').show();
        }
        if($("input[name='primary_home']:checked").val()) {} else {
           errStatus = 1;
           $('#err-primary_home').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //4th step validation
    $('#forth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#use_of_the_property").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-use_of_the_property').show();
        }
        if( jQuery("#year_built").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-year_built').show();
        }
        if( jQuery("#construction_type").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-construction_type').show();
        }
        if( jQuery("#roof_type").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-roof_type').show();
        }
        if( jQuery("#roof_shape").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-roof_shape').show();
        }
        if( jQuery("#square_feet").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-square_feet').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //5th step validation
    $('#fifth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#number_of_rooms").val().length > 0 ) {} else {
           errStatus = 1;
           jQuery('#err-number_of_rooms').show();
        }
        if( jQuery("#number_of_stories").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-number_of_stories').show();
        }
        if( jQuery("#contents").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-contents').show();
        }
        if( jQuery("#liability_limits").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-liability_limits').show();
        }
        if( jQuery("#medical_payments").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-medical_payments').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //6th step validation
    $('#sixth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if (jQuery("input[name='insurance_claims']:checked").val()) {
            if (jQuery("input[name='insurance_claims']:checked").val() == 'Yes') {
                if( jQuery("#type_of_loss").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-type_of_loss').show();
                }
                if( jQuery("#paid_by_carrier").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-paid_by_carrier').show();
                }
                if( jQuery("#date_of_occurance").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-date_of_occurance').show();
                }
            }
        }else{
            errStatus = 1;
            jQuery('#err-insurance_claims').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //7th step validation
    $('#sevth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#have_any_pets").val().length > 0 ) {} else {
           errStatus = 1;
           jQuery('#err-have_any_pets').show();
        }
        if( jQuery("#gated_community").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-gated_community').show();
        }
        if( jQuery("#burglar_alarm").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-burglar_alarm').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //8th step validation
    $('#eight_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if (jQuery("input[name='roof_replaced']:checked").val()) {
            if (jQuery("input[name='roof_replaced']:checked").val() == 'Yes') {
                if( jQuery("#roof_replaced_year").val().length > 1 ) {} else {
                   errStatus = 1;
                   $('#err-roof_replaced_year').show();
                } 
                if($("input[name='built_over_sand']:checked").val()) {} else {
                   errStatus = 1;
                   $('#err-built_over_sand').show();
                }
                if($("input[name='built_over_water']:checked").val()) {} else {
                   errStatus = 1;
                   $('#err-built_over_water').show();
                }
                if( jQuery("#roof_year").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-roof_year').show();
                }
                if( jQuery("#electrical_year").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-electrical_year').show();
                }
                if( jQuery("#plumbing_year").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-plumbing_year').show();
                }
                if( jQuery("#heating_year").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-heating_year').show();
                } 
            }
        }else{
            errStatus = 1;
            jQuery('#err-roof_replaced').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //9th step validation
    $('#ninth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        

        if($("input[name='sinkhole_activity']:checked").val()) {} else {
           errStatus = 1;
           $('#err-sinkhole_activity').show();
        }

        if (jQuery("input[name='swimming_pool']:checked").val()) {
            if (jQuery("input[name='swimming_pool']:checked").val() == 'Yes') {
                if( jQuery("#swimming_pool_ground").val().length > 1 ) {} else {
                   errStatus = 1;
                   $('#err-swimming_pool_ground').show();
                } 
                if( jQuery("#swimming_pool_foundation").val().length > 1 ) {} else {
                   errStatus = 1;
                   jQuery('#err-swimming_pool_foundation').show();
                }
            }
        }else{
            errStatus = 1;
            jQuery('#err-swimming_pool').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //10th step validation
    $('#tenth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        
        if( jQuery("#house_frame").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-house_frame').show();
        }
        if( jQuery("#primary_heating").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-primary_heating').show();
        }
        if( jQuery("#hydrant_feet").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-hydrant_feet').show();
        }
        if( jQuery("#fire_station").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-fire_station').show();
        }
        if($("input[name='flood_zone']:checked").val()) {} else {
           errStatus = 1;
           $('#err-flood_zone').show();
        }

        if (jQuery("input[name='cu_insured']:checked").val()) {
            if (jQuery("input[name='cu_insured']:checked").val() == 'Yes') {
                if( jQuery("#namedInsured").val().length > 1 ) {} else {
                   errStatus = 1;
                   $('#err-namedInsured').show();
                }
            }
        }else{
            errStatus = 1;
            jQuery('#err-cu_insured').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });


    //11th step validation
    $('#elvnth_step').on('click',function(e){
        e.preventDefault();
        errStatus = 0;

        if($("input[name='gender']:checked").val()) {} else {
           errStatus = 1;
           $('#err-gender').show();
        }
        if($("input[name='maritalStatus']:checked").val()) {} else {
           errStatus = 1;
           $('#err-maritalStatus').show();
        }

        if($("input[name='ownRent']:checked").val()) {} else {
           errStatus = 1;
           $('#err-ownRent').show();
        }
        if($("input[name='suspended']:checked").val()) {} else {
           errStatus = 1;
           $('#err-suspended').show();
        }
        if($("input[name='faultAccidents']:checked").val()) {} else {
           errStatus = 1;
           $('#err-faultAccidents').show();
        }
        if( jQuery("#educationLevel").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-educationLevel').show();
        }
        if( jQuery("#occupation").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-occupation').show();
        }
        if( jQuery("#LicenseStatus").val().length > 1 ) {} else {
           errStatus = 1;
           $('#err-LicenseStatus').show();
        }
        if(errStatus == 0) {
          $('.err').hide();
        }
    });

    //final step submit
    jQuery('#btnsubmit').on('click',function(e){
        e.preventDefault();
        errStatus = 0;
        if( jQuery("#fname").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-fname').show();
        }
        if( jQuery("#lname").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-lname').show();
        }
        var email = jQuery("#email").val();
        if( IsEmail(email) ) {} else {
           errStatus = 1;
           jQuery('#err-email').show();
        }
        if( jQuery("#tel").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-tel').show();
        }
        if( jQuery("#dob").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-dob').show();
        }
        if( jQuery("#adress").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-adress').show();
        }
        if( jQuery("#city").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-city').show();
        }
        if( jQuery("#state").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-state').show();
        }
        if( jQuery("#zip").val().length > 1 ) {} else {
           errStatus = 1;
           jQuery('#err-zip').show();
        }

        if(errStatus == 0) {
          jQuery('.err').hide();
          submitForm()
        }
    });
    var current_fs, next_fs, previous_fs, btn; //fieldsets
    var opacity;
    var current = 1;
    var steps = $("fieldset").length;

    Circlle('.round', current);

    $(".next").click(function(){
        if (errStatus == 0) {
            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            //Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            Circlle('.round', ++current);
            $("html, body").animate({ scrollTop: "0" });
        }
    });

    $(".previous").click(function(){

        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();

        //Remove class active
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

        //show the previous fieldset
        previous_fs.show();

        //hide the current fieldset with style
        current_fs.animate({opacity: 0}, {
            step: function(now) {
                // for making fielset appear animation
                opacity = 1 - now;

                current_fs.css({
                    'display': 'none',
                    'position': 'relative'
                });
                previous_fs.css({'opacity': opacity});
            },
            duration: 500
        });
        Circlle('.round', --current);
        $("html, body").animate({ scrollTop: "0" });
    });
    function Circlle(el, curStep){
        var percent = parseFloat(1 / steps) * curStep;
        percentval = percent.toFixed(2);
        $('.round').attr('data-value', percentval);
        $(el).circleProgress({value: percent, fill: {color: '#054f93'}}).on('circle-animation-progress', function(event, progress, stepValue){
            if(percent < 1 ){
                $(this).find('strong').text(String(percent.toFixed(2)).substr(2)+'%');
            }else{
                $(this).find('strong').text('100%');
            }
        });  
    };

    $(".submit").click(function(){
        return false;
    })

    // select 2 plugin code
    $(".single").select2({});
    // on radio option select add class
    $(function() {
        var $radioButtons = $('input[type="radio"]');
        $radioButtons.click(function() {
            $radioButtons.each(function() {
                $(this).parent().toggleClass('selected', this.checked);
            });
        });
    });

    //check lease own value and show hide payments question
    $("input[name=ownLease]").on('change', function(){
        $(".make_pay")[this.id =='Own'?'slideDown':'slideUp']();
    });
    $("input[name=cu_insured]").on('change', function(){
        $("#insured_named")[this.id =='Yes'?'slideDown':'slideUp']();
    });

    $('.insurance_claims > div > input').change(function(){
        $('.insurance_claims-yes')[this.id =='insurance_claims_0'?'slideDown':'slideUp']();
    });

    $('.roof_replaced > div > input').change(function(){
        $('.roof_replaced-yes')[this.id =='roof_replaced_0'?'slideDown':'slideUp']();
    });

    $('.swimming_pool > div > input').change(function(){
        $('.swimming_pool-ground')[this.id =='swimming_pool_0'?'slideDown':'slideUp']();
    });
    $('.cu_insured > div > input').change(function(){
        $('.current-insured-named')[this.id =='cu_insured_0'?'slideDown':'slideUp']();
    });
});

function submitForm(){
    var fname = jQuery("#fname").val();
    var lname = jQuery("#lname").val();
    var email = jQuery("#email").val(); 
    var phone = jQuery("#tel").val();
    var DOB = jQuery("#dob").val();
    var adress = jQuery("#adress").val();
    var city = jQuery("#city").val();
    var state = jQuery("#state").val();
    var zip = jQuery("#zip").val();
    var home = jQuery("input[name='home']:checked").val();
    var property_address = jQuery("#p-adress").val();
    var unit = jQuery("#p-unit").val();
    var vinnumbr = '';
    var occupancy = jQuery("input[name='occupancy']:checked").val();
    var primary_home = jQuery("input[name='primary_home']:checked").val();
    var use_property = jQuery("#use_of_the_property").val();
    var year_built = jQuery("#year_built").val();
    var square_feet = jQuery("#square_feet").val();
    var construction_type = jQuery("#construction_type").val();
    var roof_type = jQuery("#roof_type").val();
    var roof_shape = jQuery("#roof_shape").val();
    var number_of_rooms = jQuery("#number_of_rooms").val();
    var number_of_stories = jQuery("#number_of_stories").val();
    var contents = jQuery("#contents").val();
    var liability_limits = jQuery("#liability_limits").val();
    var medical_payments = jQuery("#medical_payments").val();
    var residence_passed = jQuery("input[name='residence_passed']:checked").val();
    var insurance_claims = jQuery("input[name='insurance_claims']:checked").val();
    var type_of_loss = jQuery("#type_of_loss").val();
    var paid_by_carrier = jQuery("#paid_by_carrier").val();
    var date_of_occurance = jQuery("#date_of_occurance").val();
    var have_any_pets = jQuery("#have_any_pets").val();
    var gated_community = jQuery("#gated_community").val();
    var burglar_alarm = jQuery("#burglar_alarm").val();
    var roof_replaced = jQuery("input[name='roof_replaced']:checked").val();
    var roof_replaced_year = jQuery("#roof_replaced_year").val();
    var built_over_sand = jQuery("input[name='built_over_sand']:checked").val();
    var built_over_water = jQuery("input[name='built_over_water']:checked").val();
    var roof_year = jQuery("#roof_year").val();
    var electrical_year = jQuery("#electrical_year").val();
    var plumbing_year = jQuery("#plumbing_year").val();
    var heating_year = jQuery("#heating_year").val();
    var sinkhole_activity = jQuery("input[name='sinkhole_activity']:checked").val(); 
    var swimming_pool = jQuery("input[name='swimming_pool']:checked").val();
    var swimming_pool_ground = jQuery("#swimming_pool_ground").val();
    var swimming_pool_foundation = jQuery("#swimming_pool_foundation").val();
    var house_frame = jQuery("#house_frame").val();
    var primary_heating = jQuery("#primary_heating").val();
    var hydrant_feet = jQuery("#hydrant_feet").val();
    var fire_station = jQuery("#fire_station").val();
    var flood_zone = jQuery("input[name='flood_zone']:checked").val();
    var cu_insured = jQuery("input[name='cu_insured']:checked").val();
    var namedInsured = jQuery("#namedInsured").val();
    var gender = jQuery("input[name='gender']:checked").val();
    var maritalStatus = jQuery("input[name='maritalStatus']:checked").val();
    var educationLevel = jQuery("input[name='ownRent']:checked").val();
    var occupation = jQuery("input[name='suspended']:checked").val();
    var ownRent = jQuery("input[name='faultAccidents']:checked").val();
    var LicenseStatus = jQuery("#educationLevel").val();
    var suspended = jQuery("#occupation").val();
    var faultAccidents = jQuery("#LicenseStatus").val();
    jQuery.ajax({

        type: "POST",
        url: "/wp-content/themes/astra/assets/php/homes-form-process.php",
        data: {
            fname : fname,
            lname : lname,
            email : email,
            phone : phone,
            adress : adress,
            DOB : DOB,
            city : city,
            state : state,
            zip : zip,
            home : home,
            property_address : property_address,
            unit : unit,
            vinnumbr : vinnumbr,
            occupancy : occupancy,
            primary_home : primary_home,
            use_property : use_property,
            year_built : year_built,
            square_feet : square_feet,
            construction_type : construction_type,
            roof_type : roof_type,
            roof_shape : roof_shape,
            number_of_rooms : number_of_rooms,
            number_of_stories : number_of_stories,
            contents : contents,
            liability_limits : liability_limits,
            medical_payments : medical_payments,
            residence_passed : residence_passed,
            insurance_claims : insurance_claims,
            type_of_loss : type_of_loss,
            paid_by_carrier : paid_by_carrier,
            date_of_occurance : date_of_occurance,
            have_any_pets : have_any_pets,
            gated_community : gated_community,
            burglar_alarm : burglar_alarm,
            roof_replaced : roof_replaced,
            roof_replaced_year : roof_replaced_year,
            built_over_sand : built_over_sand,
            built_over_water : built_over_water,
            roof_year : roof_year,
            electrical_year : electrical_year,
            plumbing_year : plumbing_year,
            heating_year : heating_year,
            sinkhole_activity : sinkhole_activity,
            swimming_pool : swimming_pool,
            swimming_pool_ground : swimming_pool_ground,
            swimming_pool_foundation : swimming_pool_foundation,
            house_frame : house_frame,
            primary_heating : primary_heating,
            hydrant_feet : hydrant_feet,
            fire_station : fire_station,
            flood_zone : flood_zone,
            cu_insured : cu_insured,
            namedInsured : namedInsured,
            gender : gender,
            maritalStatus : maritalStatus,
            educationLevel : educationLevel,
            occupation : occupation,
            ownRent : ownRent,
            LicenseStatus : LicenseStatus,
            suspended : suspended,
            faultAccidents : faultAccidents,
            },
        success : function(text){
            if (text == "success"){
                formSuccess();
            } else {
                submitMSG(false,text);
            }
        }
    });
}

function formSuccess(){
    jQuery("#msform")[0].reset();
    submitMSG(true, "Success! Your message has been sent.");
    jQuery('.thankyou-call-us').slideDown('slow');
}

function submitMSG(valid, msg){
    if(valid){
        var msgClasses = " tada text-success";
    } else {
        var msgClasses = " text-danger";
    }
    jQuery("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
}

function IsEmail(email) {
   var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
   if(!regex.test(email)) {
     return false;
   }else{
     return true;
   }
}
</script>
<?php get_footer(); ?>