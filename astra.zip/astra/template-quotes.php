<?php /* Template Name: Quotes */ ?>

<?php get_header(); ?>
<?php 
if(isset($_GET['product'])) {
	$product = $_GET['product'];
	if ($product == 'auto') {
		get_template_part( 'template-parts/content', 'cars');
	}elseif($product == 'home'){
		get_template_part( 'template-parts/content', 'home');
	}
}else{
?>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style type="text/css">
.title{
    margin-top: 150px;
    text-align: center;
}
* {
    margin: 0;
    padding: 0
}
h1,h2,h3,h4,h5,h6, a:focus{
    color: #054f93;
    border-color: #054f93;
}
.card-link{
	display: block;
    max-width: 224px;
    min-height: 200px;
    margin: 0px auto;
    box-shadow: 2px 5px 8px 0 rgb(0 0 0 / 10%);
    border-radius: 5px;
    overflow: hidden;
    color: #054f93;;
    transition: .5s;
}
.card-link:hover{
	background: #054f93;;
	color: #fff;

}
.card-link .card{
	justify-content: center;
    display: flex;
    align-items: center;
    min-height: 200px;
    font-size: 44px;
    padding: 20px;
    box-sizing: border-box;
    background: transparent;
}
.card-link .card i{
	font-size: 100px;
}
.custom-container{
	max-width: 700px;
    margin: 0 auto;
}
</style>
<section class="container-fluid">
	<div class="container">
		<div class="title mobile-mt-80">
			<h1>
				Better insurance starts here
			</h1>
		</div>
		<div class="custom-container py-5">
			<div class="row">
				<div class="col-md-6 mb-5">
					<a class="card-link" href="?product=auto">
						<div class="card">
							<div class="icon">
								<i class="fas fa-car"></i>
							</div>
							<div class="card-title">
								<span>Auto</span>
							</div>
						</div>
					</a>
				</div>
				<div class="col-md-6 mb-5">
					<a class="card-link" href="?product=home">
						<div class="card">
							<div class="icon">
								<i class="fas fa-home"></i>
							</div>
							<div class="card-title">
								<span>Home</span>
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>
<?php 

}

?>
<?php get_footer(); ?>